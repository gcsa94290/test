# **wegir**

Application mobile de navigation collaborative pour rouler en convoi. Voir `PROGRESS.md` pour l'avancement par phase.

## Stack technique

- **Framework** : React Native via Expo (managed + dev client), TypeScript strict
- **Routing** : Expo Router (file-based, dossier `app/`)
- **État** : Zustand (stores par feature) + TanStack Query (données serveur)
- **Cartographie** : `@rnmapbox/maps` (Mapbox)
- **Itinéraire** : Mapbox Directions (derrière une interface, SDK natif possible plus tard)
- **Géoloc background** : `react-native-background-geolocation` (stubé pour l'instant, derrière `services/geolocation`)
- **API** : Node.js + Express
- **Base de données** : MySQL (admin via phpMyAdmin)
- **Temps réel** : WebSockets (Socket.IO) pour les positions live du convoi
- **Images** : Cloudinary (avatars, photos d'alerte), upload signé côté API
- **Auth** : JWT custom côté API
- **Notifications** : Expo Push Notifications
- **Audio push-to-talk** : LiveKit (Phase 5, derrière `audio.service`)
- **Qualité** : ESLint (flat) + Prettier + TypeScript strict

### Choix de stack notables

- Backend classique (Node/Express + MySQL + Cloudinary), pas de Firebase. Le client API vit dans `src/lib/api.ts`.
- Le natif difficile (géoloc background, audio) est stubé derrière des interfaces avec une impl mock, pour avancer l'UI sans build natif. On branche le natif quand l'UI tient.
- Toutes les icônes sont des **SVG dessinés à la main** dans `src/components/icons`, aucune librairie d'icônes.

## Prérequis et lancement

Cette stack utilise des modules natifs (Mapbox), donc **Expo Go ne suffit pas** : il faut un dev client.

```bash
npm install
cp .env.example .env   # puis renseigner le token Mapbox et l'URL de l'API
npx expo run:android   # ou run:ios (Mac requis), construit le dev client
```

Aucun secret n'est commité : tout passe par `.env` (voir `.env.example`).

## Scripts

```bash
npm run typecheck   # tsc --noEmit
npm run lint        # eslint
npm run format      # prettier --write
```

## Architecture

```
app/                     Routes Expo Router (fines : composent des features)
  (onboarding)/          Welcome, features, permissions
  (auth)/                Sign-in, sign-up
  (main)/                Tabs : home, navigation, convoy, profile (+ settings, replay)
src/
  features/<feature>/    components / hooks / services / stores / types par feature
  components/            Primitives UI partagées + icônes SVG
  theme/                 Tokens centralisés (couleurs, typo, espacements, rayons, ombres)
  lib/                   Init clients externes (api, mapbox, queryClient)
  services/              Services transverses (geolocation, notifications, analytics)
  stores/                Stores globaux
  hooks/ utils/ types/   Partagés génériques, helpers purs, modèles domaine
  constants/             Config et clés de query
```

Principe : `app/` mince, toute la matière dans `src/features/<feature>/`. Le strictement partagé monte dans `src/components`, `src/theme`, `src/utils`.

---

**Présentation**
Wegir est une application de navigation collaborative conçue pour faciliter les déplacements en groupe. L'objectif est de permettre à chaque membre du convoi de visualiser les autres en temps réel sur une carte interactive, tout en partageant des informations critiques (danger, météo, destination) pour garantir la sécurité et la cohésion du groupe.

**Vision pour l'application mobile (prio iOS puis android dans plusieur mois) Le projet actuel est un prototype web (HTML/Leaflet). L'objectif est de le porter en application native iOS**

- Accéder aux fonctionnalités GPS en arrière-plan.
- Améliorer la fluidité et les performances de rendu cartographique.
- Utiliser les notifications natives pour les alertes de sécurité.
- Offrir une expérience utilisateur (UX) optimisée pour les écrans mobiles.

**Fonctionnalités clés (Basé sur le prototype)**
Voici les modules principaux que l'application doit implémenter :

1. Navigation & Carte
   Affichage cartographique : Utilisation d'une carte fluide (type MapKit ou Mapbox).
   HUD (Heure/Vitesse) : Affichage de la vitesse instantanée et des infos de navigation.
   Recentrage auto : Bouton pour recentrer la carte sur la position de l'utilisateur.
2. Gestion de Convoi
   Code de groupe : Système de partage de code pour rejoindre un convoi.
   Mini-bar de convoi : Liste des membres actifs avec leur statut (distance, état de connexion).
   Visibilité temps réel : Marquage des membres du groupe sur la carte. 3. Alertes & Sécurité
   Signalement rapide : Menu permettant de signaler des dangers (ex: travaux, radar, accident) avec des icônes explicites.
   Flux d'alertes : Affichage des alertes en haut de l'écran avec effet visuel. 4. Services Additionnels
   Météo locale : Intégration de données météo basées sur la position.
   Commandes vocales : Bouton d'activation vocale pour les mains libres.

**Stack Technique souhaitée (Suggestion)**

- Langage : React Native (recommandé pour iOS).
- Framework UI : React Native (pour le design moderne et fluide).
- Cartographie : MapKit ou Mapbox SDK.
- Backend : Node.js + Express + MySQL, temps réel via Socket.IO, images sur Cloudinary.

**Roadmap de développement**

- MVP (Minimum Viable Product) : Affichage de la carte et géolocalisation en temps réel de l'utilisateur.
- Gestion de groupe : Création/Rejoindre un convoi via un système de code.
- Signalements : Implémentation du système d'alertes.
- Polish : Intégration des effets de flou, animations et design final.
