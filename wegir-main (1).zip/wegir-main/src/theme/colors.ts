export interface Palette {
  mode: 'dark' | 'light';

  bgBase: string;
  bgSunken: string;
  bgElevated: string;
  surface: string;
  surfaceHigh: string;
  border: string;
  borderStrong: string;

  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  textFaint: string;

  accent: string;
  accentStrong: string;
  accentSoft: string;
  onAccent: string;

  amber: string;
  amberSoft: string;
  danger: string;
  success: string;
  info: string;
  pink: string;
  indigo: string;
}

const accent = '#19e3c4';
const amber = '#ff9f0a';

export const darkPalette: Palette = {
  mode: 'dark',

  bgBase: '#0b0f14',
  bgSunken: '#070a0e',
  bgElevated: '#10161f',
  surface: '#161d27',
  surfaceHigh: '#1e2733',
  border: '#222c38',
  borderStrong: '#2f3a48',

  textPrimary: '#f4f7fa',
  textSecondary: '#c4ccd6',
  textMuted: '#97a3b4',
  textFaint: '#6b7785',

  accent,
  accentStrong: '#0fa890',
  accentSoft: '#06231f',
  onAccent: '#042520',

  amber,
  amberSoft: '#ffc247',
  danger: '#ff453a',
  success: '#32d74b',
  info: '#4da3ff',
  pink: '#ff6b9d',
  indigo: '#7c83ff',
};

export const lightPalette: Palette = {
  mode: 'light',

  bgBase: '#f4f7fa',
  bgSunken: '#e9eef4',
  bgElevated: '#ffffff',
  surface: '#ffffff',
  surfaceHigh: '#eef2f7',
  border: '#d8e0ea',
  borderStrong: '#c2cdda',

  textPrimary: '#0a0e13',
  textSecondary: '#3a4654',
  textMuted: '#5c6675',
  textFaint: '#97a3b4',

  accent: '#0e9c83',
  accentStrong: '#0a7a67',
  accentSoft: '#d7f5ee',
  onAccent: '#ffffff',

  amber: '#e07d00',
  amberSoft: '#ffb838',
  danger: '#e23b30',
  success: '#1faa3a',
  info: '#1f7fe0',
  pink: '#e0467c',
  indigo: '#5a62e0',
};

// Stable per-member colors. Members get one by joining order, wrapping around.
export const memberColors = [
  accent,
  amber,
  '#ff6b9d',
  '#7c83ff',
  '#4da3ff',
  '#32d74b',
  '#ffc247',
  '#c084fc',
] as const;

export function memberColor(index: number): string {
  return memberColors[index % memberColors.length] as string;
}
