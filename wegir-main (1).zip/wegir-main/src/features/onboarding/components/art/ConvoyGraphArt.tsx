import Svg, { Circle, Line, Path } from 'react-native-svg';

import { useTheme } from '@/theme';

const CURVE = 'M40 195 C 100 178 138 124 195 112 S 265 60 290 48';

export function ConvoyGraphArt({ size = 280 }: { size?: number }) {
  const { palette } = useTheme();
  return (
    <Svg width={size} height={size * 0.72} viewBox="0 0 320 230">
      {[95, 160, 225].map((x) => (
        <Line key={`v${x}`} x1={x} y1="28" x2={x} y2="205" stroke={palette.border} strokeWidth={1} />
      ))}
      {[70, 120, 170].map((y) => (
        <Line key={`h${y}`} x1="32" y1={y} x2="298" y2={y} stroke={palette.border} strokeWidth={1} />
      ))}
      <Path d={CURVE} stroke={palette.accent} strokeWidth={3.5} strokeLinecap="round" fill="none" />
      <Circle cx="290" cy="48" r="10" fill={palette.amber} />
      <Circle cx="205" cy="104" r="9" fill={palette.info} />
      <Circle cx="150" cy="120" r="9" fill={palette.pink} />
      <Circle cx="40" cy="195" r="11" fill={palette.bgBase} stroke={palette.accent} strokeWidth={3} />
      <Circle cx="40" cy="195" r="5" fill={palette.accent} />
    </Svg>
  );
}
