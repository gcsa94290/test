import Svg, { Circle, G, Line, Path } from 'react-native-svg';

import { useTheme } from '@/theme';

interface Dot {
  x: number;
  y: number;
  color: string;
  r: number;
  self?: boolean;
  crown?: boolean;
}

interface Segment {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export function ConvoyPathArt({ size = 280 }: { size?: number }) {
  const { palette } = useTheme();

  const dots: Dot[] = [
    { x: 50, y: 196, color: palette.accent, r: 13, self: true },
    { x: 110, y: 168, color: palette.pink, r: 9 },
    { x: 166, y: 138, color: palette.info, r: 9 },
    { x: 220, y: 106, color: palette.indigo, r: 9 },
    { x: 274, y: 72, color: palette.amber, r: 11, crown: true },
  ];

  const band = dots.map((d, i) => `${i === 0 ? 'M' : 'L'} ${d.x} ${d.y}`).join(' ');

  const segments: Segment[] = [];
  for (let i = 0; i < dots.length - 1; i += 1) {
    const a = dots[i];
    const b = dots[i + 1];
    if (!a || !b) continue;
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const len = Math.hypot(dx, dy) || 1;
    const ux = dx / len;
    const uy = dy / len;
    const padA = a.r + 6;
    const padB = b.r + 6;
    segments.push({
      x1: a.x + ux * padA,
      y1: a.y + uy * padA,
      x2: b.x - ux * padB,
      y2: b.y - uy * padB,
    });
  }

  return (
    <Svg width={size} height={size * 0.78} viewBox="0 0 320 230">
      <Path
        d={band}
        stroke={palette.surfaceHigh}
        strokeWidth={20}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        opacity={0.7}
      />
      {segments.map((s, i) => (
        <Line
          key={i}
          x1={s.x1}
          y1={s.y1}
          x2={s.x2}
          y2={s.y2}
          stroke={palette.accent}
          strokeWidth={3}
          strokeLinecap="round"
          strokeDasharray="0.5 8"
        />
      ))}
      {dots.map((d, i) => (
        <G key={i}>
          {d.crown ? (
            <Path
              d={`M${d.x - 11} ${d.y - 20} l5 7 6 -10 6 10 5 -7 -2 14 h-18 z`}
              fill={palette.amber}
            />
          ) : null}
          {d.self ? (
            <>
              <Circle cx={d.x} cy={d.y} r={d.r} fill={palette.bgBase} stroke={d.color} strokeWidth={3} />
              <Circle cx={d.x} cy={d.y} r={6} fill={d.color} />
            </>
          ) : (
            <Circle cx={d.x} cy={d.y} r={d.r} fill={d.color} />
          )}
        </G>
      ))}
    </Svg>
  );
}
