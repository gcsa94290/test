import { View } from 'react-native';
import Svg, { Circle, Defs, Path, RadialGradient, Stop } from 'react-native-svg';

import { Text } from '@/components';
import { useTheme } from '@/theme';

export function AlertArt({ size = 280 }: { size?: number }) {
  const { palette, radius, spacing } = useTheme();
  const height = size * 0.72;

  return (
    <View style={{ width: size, height, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={height} viewBox="0 0 320 230" style={{ position: 'absolute' }}>
        <Defs>
          <RadialGradient id="alertGlow" cx="50%" cy="58%" r="50%">
            <Stop offset="0%" stopColor={palette.amber} stopOpacity={0.5} />
            <Stop offset="100%" stopColor={palette.amber} stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx="160" cy="132" r="100" fill="url(#alertGlow)" />
        <Path
          d="M160 70 L236 192 a12 12 0 0 1 -10 18 H94 a12 12 0 0 1 -10 -18 Z"
          fill={palette.amber}
        />
        <Path d="M160 112 V152" stroke={palette.bgBase} strokeWidth={8} strokeLinecap="round" />
        <Circle cx="160" cy="176" r="5" fill={palette.bgBase} />
      </Svg>

      <View
        style={{
          position: 'absolute',
          top: 8,
          backgroundColor: palette.bgElevated,
          borderColor: palette.amber,
          borderWidth: 1,
          borderRadius: radius.pill,
          paddingHorizontal: spacing.md,
          paddingVertical: spacing.xs,
        }}
      >
        <Text variant="caption" style={{ color: palette.amber }}>
          Travaux · 500 m
        </Text>
      </View>
    </View>
  );
}
