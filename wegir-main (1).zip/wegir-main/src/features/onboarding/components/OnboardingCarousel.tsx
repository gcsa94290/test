import { useRouter } from 'expo-router';
import { useRef, useState, type ComponentType } from 'react';
import {
  Animated,
  Pressable,
  ScrollView,
  useWindowDimensions,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BackgroundOrbs, Button, Icon, Text } from '@/components';
import { useTheme } from '@/theme';

import { AlertArt } from './art/AlertArt';
import { ConvoyGraphArt } from './art/ConvoyGraphArt';
import { ConvoyPathArt } from './art/ConvoyPathArt';
import { PaginationDots } from './PaginationDots';

interface Slide {
  key: string;
  Art: ComponentType<{ size?: number }>;
  title: string;
  subtitle: string;
  brand?: boolean;
}

const SLIDES: Slide[] = [
  {
    key: 'together',
    Art: ConvoyPathArt,
    title: 'Roulez ensemble.\nRestez ensemble.',
    subtitle:
      'La navigation qui coordonne tout un groupe de véhicules en temps réel, sur le même trajet.',
    brand: true,
  },
  {
    key: 'live',
    Art: ConvoyGraphArt,
    title: 'Chaque véhicule,\nvisible en direct',
    subtitle:
      'Voyez la position de tout le convoi sur la carte, avec la couleur de chacun et l’ordre dans la file.',
  },
  {
    key: 'alert',
    Art: AlertArt,
    title: 'Un danger vu,\ntout le groupe prévenu',
    subtitle:
      'Accident, bouchon, contrôle : signalé en un geste, l’alerte remonte instantanément à tout le convoi.',
  },
];

export function OnboardingCarousel() {
  const router = useRouter();
  const { palette, spacing, radius } = useTheme();
  const { width } = useWindowDimensions();
  const [scrollX] = useState(() => new Animated.Value(0));
  const scrollRef = useRef<ScrollView>(null);
  const [index, setIndex] = useState(0);

  const artSize = Math.min(width * 0.82, 330);
  const isLast = index >= SLIDES.length - 1;

  const finish = () => router.push('/(onboarding)/permissions');
  const goTo = (i: number) => scrollRef.current?.scrollTo({ x: i * width, animated: true });
  const next = () => (isLast ? finish() : goTo(index + 1));

  const onScroll = Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } } }], {
    useNativeDriver: false,
  });
  const onMomentumEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) =>
    setIndex(Math.round(e.nativeEvent.contentOffset.x / width));

  return (
    <View style={{ flex: 1, backgroundColor: palette.bgBase }}>
      <BackgroundOrbs />
      <SafeAreaView style={{ flex: 1 }}>
        <Animated.ScrollView
          ref={scrollRef}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          scrollEventThrottle={16}
          onScroll={onScroll}
          onMomentumScrollEnd={onMomentumEnd}
          style={{ flex: 1 }}
        >
          {SLIDES.map((slide) => (
            <View
              key={slide.key}
              style={{
                width,
                flex: 1,
                paddingHorizontal: spacing.xl,
                paddingBottom: spacing.md,
              }}
            >
              <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                <slide.Art size={artSize} />
              </View>
              <View style={{ gap: spacing.md }}>
                {slide.brand ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
                    <View
                      style={{
                        width: 30,
                        height: 30,
                        borderRadius: radius.sm,
                        backgroundColor: palette.accentSoft,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="convoy" size={18} color={palette.accent} />
                    </View>
                    <Text variant="overline" color="accent">
                      Wegir
                    </Text>
                  </View>
                ) : null}
                <Text variant="display">{slide.title}</Text>
                <Text variant="body" color="muted">
                  {slide.subtitle}
                </Text>
              </View>
            </View>
          ))}
        </Animated.ScrollView>

        <View style={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.lg, gap: spacing.lg }}>
          <PaginationDots scrollX={scrollX} count={SLIDES.length} width={width} />

          {index === 0 ? (
            <View style={{ gap: spacing.md }}>
              <Button label="Commencer" onPress={next} />
              <Pressable
                onPress={() => router.push('/(auth)/sign-in')}
                style={{ alignSelf: 'center' }}
              >
                <Text variant="label" color="muted">
                  Déjà un compte ? <Text color="accent">Se connecter</Text>
                </Text>
              </Pressable>
            </View>
          ) : (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
              <Button label="Suivant" onPress={next} style={{ flex: 1 }} />
              <Pressable onPress={finish} style={{ paddingHorizontal: spacing.md }}>
                <Text variant="bodyStrong" color="muted">
                  Passer
                </Text>
              </Pressable>
            </View>
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}
