import { Animated, View } from 'react-native';

import { useTheme } from '@/theme';

interface PaginationDotsProps {
  scrollX: Animated.Value;
  count: number;
  width: number;
}

export function PaginationDots({ scrollX, count, width }: PaginationDotsProps) {
  const { palette } = useTheme();

  return (
    <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6 }}>
      {Array.from({ length: count }).map((_, i) => {
        const inputRange = [(i - 1) * width, i * width, (i + 1) * width];
        const dotWidth = scrollX.interpolate({
          inputRange,
          outputRange: [8, 22, 8],
          extrapolate: 'clamp',
        });
        const opacity = scrollX.interpolate({
          inputRange,
          outputRange: [0.3, 1, 0.3],
          extrapolate: 'clamp',
        });
        return (
          <Animated.View
            key={i}
            style={{
              height: 8,
              width: dotWidth,
              borderRadius: 4,
              backgroundColor: palette.accent,
              opacity,
            }}
          />
        );
      })}
    </View>
  );
}
