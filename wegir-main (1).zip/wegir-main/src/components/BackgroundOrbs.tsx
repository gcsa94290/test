import { StyleSheet } from 'react-native';
import Svg, { Circle, Defs, RadialGradient, Stop } from 'react-native-svg';

import { useTheme } from '@/theme';

interface BackgroundOrbsProps {
  color?: string;
  cx?: string;
  cy?: string;
}

// Single soft ambient glow behind the content (the "orb" look of the mockups).
export function BackgroundOrbs({ color, cx = '30%', cy = '22%' }: BackgroundOrbsProps) {
  const { palette } = useTheme();
  const tint = color ?? palette.accent;

  return (
    <Svg style={StyleSheet.absoluteFill} pointerEvents="none">
      <Defs>
        <RadialGradient id="orb" cx="50%" cy="50%" r="50%">
          <Stop offset="0%" stopColor={tint} stopOpacity={0.18} />
          <Stop offset="100%" stopColor={tint} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Circle cx={cx} cy={cy} r="55%" fill="url(#orb)" />
    </Svg>
  );
}
