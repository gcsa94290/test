import type * as NotificationsModule from 'expo-notifications';

// Loaded lazily so importing this module does not trigger the expo-notifications
// warning at startup in Expo Go (remote push is unavailable there since SDK 53).
function getNotifications(): typeof NotificationsModule {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  return require('expo-notifications');
}

export async function requestNotificationPermission(): Promise<boolean> {
  const { status } = await getNotifications().requestPermissionsAsync();
  return status === 'granted';
}

export async function notifyLocal(title: string, body: string): Promise<void> {
  await getNotifications().scheduleNotificationAsync({
    content: { title, body },
    trigger: null,
  });
}
