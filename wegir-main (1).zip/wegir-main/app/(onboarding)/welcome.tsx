import { OnboardingCarousel } from '@/features/onboarding/components/OnboardingCarousel';

export default function Welcome() {
  return <OnboardingCarousel />;
}
