import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { Button, Screen, Text } from '@/components';
import { PermissionRow } from '@/features/onboarding/components/PermissionRow';
import { usePermissions } from '@/features/onboarding/hooks/usePermissions';
import { useAppStore } from '@/stores/app.store';

export default function Permissions() {
  const router = useRouter();
  const completeOnboarding = useAppStore((s) => s.completeOnboarding);
  const { location, notifications, requestLocation, requestNotifications } = usePermissions();

  const finish = () => {
    completeOnboarding();
    router.replace('/(main)/home');
  };

  return (
    <Screen title="Autorisations">
      <Text variant="body" color="muted">
        Pour vous guider et garder le convoi visible, l'app a besoin de deux accès.
      </Text>
      <View style={{ marginTop: 24 }}>
        <PermissionRow
          icon="recenter"
          title="Localisation"
          description="Position en direct sur la carte et guidage."
          granted={location === 'granted'}
          onRequest={requestLocation}
        />
        <PermissionRow
          icon="bell"
          title="Notifications"
          description="Alertes de sécurité et messages du convoi."
          granted={notifications === 'granted'}
          onRequest={requestNotifications}
        />
      </View>
      <View style={{ flex: 1 }} />
      <Button label="Terminer" onPress={finish} />
    </Screen>
  );
}
