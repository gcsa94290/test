import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { Button, Screen, Text } from '@/components';
import { OnboardingSlide } from '@/features/onboarding/components/OnboardingSlide';

export default function Welcome() {
  const router = useRouter();
  return (
    <Screen>
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <OnboardingSlide
          icon="convoy"
          title="Roulez ensemble, jamais seul"
          description="GCS Convois garde votre groupe soudé sur la route, en temps réel."
        />
      </View>
      <Button
        label="Commencer"
        icon="chevronRight"
        onPress={() => router.push('/(onboarding)/features')}
      />
      <Text variant="caption" color="faint" style={{ textAlign: 'center', marginTop: 12 }}>
        Convoi d'abord. La nav suit.
      </Text>
    </Screen>
  );
}
