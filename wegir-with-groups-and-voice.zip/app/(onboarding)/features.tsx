import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { Button, Icon, Screen, Text } from '@/components';
import { useTheme } from '@/theme';

const ITEMS = [
  { icon: 'route', title: 'Itinéraire unifié', text: 'Tout le convoi suit le tracé du leader.' },
  { icon: 'alert', title: 'Alertes partagées', text: 'Un danger vu, tout le groupe prévenu.' },
  { icon: 'mic', title: 'Talkie convoi', text: 'Parlez au groupe comme une CB.' },
] as const;

export default function Features() {
  const router = useRouter();
  const { palette, spacing } = useTheme();

  return (
    <Screen title="3 features signature">
      <View style={{ flex: 1, gap: spacing.xl, marginTop: spacing.lg }}>
        {ITEMS.map((item) => (
          <View
            key={item.title}
            style={{ flexDirection: 'row', gap: spacing.lg, alignItems: 'center' }}
          >
            <Icon name={item.icon} size={30} color={palette.accent} />
            <View style={{ flex: 1 }}>
              <Text variant="bodyStrong">{item.title}</Text>
              <Text variant="body" color="muted">
                {item.text}
              </Text>
            </View>
          </View>
        ))}
      </View>
      <Button
        label="Continuer"
        icon="chevronRight"
        onPress={() => router.push('/(onboarding)/permissions')}
      />
    </Screen>
  );
}
