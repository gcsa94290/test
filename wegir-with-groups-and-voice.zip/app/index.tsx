import { Redirect } from 'expo-router';

import { useAppStore } from '@/stores/app.store';

export default function Index() {
  const hasCompletedOnboarding = useAppStore((s) => s.hasCompletedOnboarding);
  return <Redirect href={hasCompletedOnboarding ? '/(main)/home' : '/(onboarding)/welcome'} />;
}
