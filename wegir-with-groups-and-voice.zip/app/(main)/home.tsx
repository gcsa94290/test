import { useRouter } from 'expo-router';

import { Button, EmptyState, Screen } from '@/components';

export default function Home() {
  const router = useRouter();
  return (
    <Screen title="Où va le convoi ?">
      <EmptyState
        icon="map"
        title="Carte Mapbox en Phase 1"
        description="Recherche de destination, position live et itinéraire arrivent ici."
      />
      <Button
        label="Partir en convoi"
        icon="convoy"
        onPress={() => router.push('/(main)/convoy')}
      />
    </Screen>
  );
}
