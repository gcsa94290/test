import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { Avatar, Button, Screen, Text } from '@/components';
import { memberColor, useTheme } from '@/theme';

export default function Profile() {
  const router = useRouter();
  const { spacing } = useTheme();

  return (
    <Screen title="Profil">
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.lg }}>
        <Avatar name="Moi" color={memberColor(0)} size={56} />
        <View>
          <Text variant="heading">Invité</Text>
          <Text variant="caption" color="muted">
            Connexion et points de contribution en Phase 2
          </Text>
        </View>
      </View>
      <View style={{ flex: 1 }} />
      <Button
        label="Réglages"
        icon="settings"
        variant="secondary"
        onPress={() => router.push('/(main)/settings')}
      />
    </Screen>
  );
}
