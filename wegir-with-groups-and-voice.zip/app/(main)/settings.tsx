import { Pressable, View } from 'react-native';

import { Icon, Screen, Text } from '@/components';
import { useAppStore, type ThemePreference } from '@/stores/app.store';
import { useTheme } from '@/theme';

const OPTIONS: { value: ThemePreference; label: string }[] = [
  { value: 'system', label: 'Automatique (système)' },
  { value: 'dark', label: 'Sombre' },
  { value: 'light', label: 'Clair' },
];

export default function Settings() {
  const { palette, spacing, tapTarget } = useTheme();
  const preference = useAppStore((s) => s.themePreference);
  const setPreference = useAppStore((s) => s.setThemePreference);

  return (
    <Screen title="Réglages">
      <Text variant="overline" color="muted">
        Apparence
      </Text>
      <View style={{ marginTop: spacing.sm }}>
        {OPTIONS.map((option) => {
          const active = option.value === preference;
          return (
            <Pressable
              key={option.value}
              onPress={() => setPreference(option.value)}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                minHeight: tapTarget,
                borderBottomWidth: 1,
                borderBottomColor: palette.border,
              }}
            >
              <Text variant="body">{option.label}</Text>
              {active ? <Icon name="check" size={22} color={palette.accent} /> : null}
            </Pressable>
          );
        })}
      </View>
    </Screen>
  );
}
