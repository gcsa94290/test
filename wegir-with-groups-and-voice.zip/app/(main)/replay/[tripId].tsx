import { useLocalSearchParams } from 'expo-router';

import { EmptyState, Screen } from '@/components';

export default function Replay() {
  const { tripId } = useLocalSearchParams<{ tripId: string }>();
  return (
    <Screen title="Rejeu de trajet">
      <EmptyState
        icon="route"
        title={`Trajet ${tripId ?? ''}`}
        description="La timeline rejouable et le partage arrivent en Phase 6."
      />
    </Screen>
  );
}
