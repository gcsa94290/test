import { useRouter } from 'expo-router';
import { useRef, useState } from 'react';
import { Alert, TextInput, View } from 'react-native';

import { Button, Screen, Text } from '@/components';
import { joinConvoy } from '@/services/convoy/api';
import { useConvoyStore } from '@/stores/convoy.store';
import { useTheme } from '@/theme';

const CODE_LENGTH = 6;

export default function JoinConvoy() {
  const router = useRouter();
  const { palette, spacing, radius } = useTheme();
  const setActiveConvoy = useConvoyStore((s) => s.setActiveConvoy);

  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<TextInput>(null);

  function handleCodeChange(text: string) {
    setCode(text.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, CODE_LENGTH));
  }

  async function handleJoin() {
    if (code.length < 4) {
      Alert.alert('Code invalide', 'Le code doit contenir au moins 4 caractères.');
      return;
    }
    setLoading(true);
    try {
      const convoy = await joinConvoy(code);
      setActiveConvoy(convoy);
      router.replace(`/(main)/convoy/${convoy.id}`);
    } catch (e) {
      Alert.alert('Introuvable', e instanceof Error ? e.message : 'Code incorrect ou convoi terminé.');
    } finally {
      setLoading(false);
    }
  }

  // Render code cells
  const cells = Array.from({ length: CODE_LENGTH }).map((_, i) => {
    const char = code[i] ?? '';
    const isActive = i === code.length && code.length < CODE_LENGTH;
    return (
      <View
        key={i}
        style={{
          width: 48,
          height: 60,
          borderRadius: radius.md,
          borderWidth: isActive ? 2 : 1,
          borderColor: isActive ? palette.accent : palette.border,
          backgroundColor: palette.surface,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text
          variant="title"
          style={{ color: char ? palette.textPrimary : palette.textFaint, letterSpacing: 2 }}
        >
          {char || '·'}
        </Text>
      </View>
    );
  });

  return (
    <Screen title="Rejoindre un convoi">
      <View style={{ flex: 1, gap: spacing.xl }}>
        <Text variant="body" style={{ color: palette.textSecondary }}>
          Saisissez le code partagé par le leader du convoi.
        </Text>

        {/* Hidden real input */}
        <TextInput
          ref={inputRef}
          value={code}
          onChangeText={handleCodeChange}
          autoCapitalize="characters"
          autoCorrect={false}
          autoFocus
          maxLength={CODE_LENGTH}
          style={{ position: 'absolute', opacity: 0, width: 1, height: 1 }}
        />

        {/* Visual code cells */}
        <View
          style={{ flexDirection: 'row', gap: spacing.sm, justifyContent: 'center' }}
          onStartShouldSetResponder={() => true}
          onResponderGrant={() => inputRef.current?.focus()}
        >
          {cells}
        </View>

        <Text
          variant="bodySmall"
          style={{ color: palette.textFaint, textAlign: 'center' }}
          onPress={() => inputRef.current?.focus()}
        >
          Touchez pour saisir le code
        </Text>
      </View>

      <View style={{ gap: spacing.sm }}>
        <Button
          label="Rejoindre"
          icon="convoy"
          onPress={handleJoin}
          loading={loading}
          disabled={code.length < 4}
        />
        <Button label="Annuler" variant="ghost" onPress={() => router.back()} disabled={loading} />
      </View>
    </Screen>
  );
}
