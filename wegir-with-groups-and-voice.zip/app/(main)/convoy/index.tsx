import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, View } from 'react-native';

import { Avatar, Button, Card, EmptyState, Icon, Screen, Text } from '@/components';
import { listMyConvoys } from '@/services/convoy/api';
import { useConvoyStore } from '@/stores/convoy.store';
import { useTheme } from '@/theme';
import type { Convoy } from '@/types/convoy';

function ConvoyCard({ convoy, onPress }: { convoy: Convoy; onPress: () => void }) {
  const { palette, spacing } = useTheme();
  const liveCount = convoy.members.filter((m) => m.presence === 'live').length;

  return (
    <Pressable onPress={onPress}>
      <Card style={{ marginBottom: spacing.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: palette.accentSoft,
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: 1,
              borderColor: palette.accent + '40',
            }}
          >
            <Icon name="convoy" size={22} color={palette.accent} />
          </View>

          <View style={{ flex: 1 }}>
            <Text variant="bodyStrong" style={{ color: palette.textPrimary }}>
              {convoy.name}
            </Text>
            {convoy.destinationName ? (
              <Text variant="bodySmall" style={{ color: palette.textMuted }}>
                → {convoy.destinationName}
              </Text>
            ) : null}
          </View>

          <View style={{ alignItems: 'flex-end', gap: 4 }}>
            {/* Code */}
            <Text
              variant="label"
              style={{ color: palette.accent, letterSpacing: 3 }}
            >
              {convoy.code}
            </Text>
            {/* Live count */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <View
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: 3,
                  backgroundColor: liveCount > 0 ? palette.success : palette.textFaint,
                }}
              />
              <Text variant="overline" style={{ color: palette.textMuted }}>
                {liveCount}/{convoy.members.length}
              </Text>
            </View>
          </View>
        </View>

        {/* Member avatars */}
        {convoy.members.length > 0 && (
          <View
            style={{
              flexDirection: 'row',
              marginTop: spacing.sm,
              paddingTop: spacing.sm,
              borderTopWidth: 1,
              borderTopColor: palette.border,
              gap: -8,
            }}
          >
            {convoy.members.slice(0, 6).map((m) => (
              <View key={m.id} style={{ marginRight: -8 }}>
                <Avatar name={m.displayName} color={m.color} size={28} />
              </View>
            ))}
            {convoy.members.length > 6 && (
              <Text
                variant="overline"
                style={{ color: palette.textMuted, marginLeft: 14, alignSelf: 'center' }}
              >
                +{convoy.members.length - 6}
              </Text>
            )}
          </View>
        )}
      </Card>
    </Pressable>
  );
}

export default function ConvoyHub() {
  const router = useRouter();
  const { spacing } = useTheme();
  const setActiveConvoy = useConvoyStore((s) => s.setActiveConvoy);

  const [convoys, setConvoys] = useState<Convoy[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  async function load(isRefresh = false) {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);
    try {
      const data = await listMyConvoys();
      setConvoys(data);
    } catch {
      // Silently ignore — user might not be authed yet
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  function openConvoy(convoy: Convoy) {
    setActiveConvoy(convoy);
    router.push(`/(main)/convoy/${convoy.id}`);
  }

  return (
    <Screen title="Convois" padded={false}>
      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, flexGrow: 1 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => load(true)} />
        }
      >
        {convoys.length === 0 && !loading ? (
          <EmptyState
            icon="convoy"
            title="Aucun convoi actif"
            description="Créez un convoi ou rejoignez celui d'un ami avec un code."
          />
        ) : (
          convoys.map((c) => (
            <ConvoyCard key={c.id} convoy={c} onPress={() => openConvoy(c)} />
          ))
        )}

        <View style={{ gap: spacing.sm, marginTop: spacing.lg }}>
          <Button
            label="Créer un convoi"
            icon="plus"
            onPress={() => router.push('/(main)/convoy/create')}
          />
          <Button
            label="Rejoindre avec un code"
            icon="qr"
            variant="secondary"
            onPress={() => router.push('/(main)/convoy/join')}
          />
        </View>
      </ScrollView>
    </Screen>
  );
}
