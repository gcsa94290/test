import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, TextInput, View } from 'react-native';

import { Button, Screen, Text } from '@/components';
import { createConvoy } from '@/services/convoy/api';
import { useConvoyStore } from '@/stores/convoy.store';
import { useTheme } from '@/theme';

export default function CreateConvoy() {
  const router = useRouter();
  const { palette, spacing, radius } = useTheme();
  const setActiveConvoy = useConvoyStore((s) => s.setActiveConvoy);

  const [name, setName] = useState('');
  const [destination, setDestination] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleCreate() {
    const trimmed = name.trim();
    if (!trimmed) {
      Alert.alert('Nom requis', 'Donnez un nom à votre convoi.');
      return;
    }
    setLoading(true);
    try {
      const convoy = await createConvoy(trimmed, destination.trim() || undefined);
      setActiveConvoy(convoy);
      router.replace(`/(main)/convoy/${convoy.id}`);
    } catch (e) {
      Alert.alert('Erreur', e instanceof Error ? e.message : 'Impossible de créer le convoi.');
    } finally {
      setLoading(false);
    }
  }

  const inputStyle = {
    backgroundColor: palette.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: palette.border,
    color: palette.textPrimary,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    fontSize: 16,
    marginBottom: spacing.sm,
  };

  return (
    <Screen title="Créer un convoi">
      <View style={{ flex: 1, gap: spacing.lg }}>
        <View>
          <Text variant="label" style={{ color: palette.textMuted, marginBottom: spacing.xs }}>
            NOM DU CONVOI *
          </Text>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Ex. Road trip Alpes"
            placeholderTextColor={palette.textFaint}
            style={inputStyle}
            maxLength={60}
            autoFocus
          />
        </View>

        <View>
          <Text variant="label" style={{ color: palette.textMuted, marginBottom: spacing.xs }}>
            DESTINATION (optionnel)
          </Text>
          <TextInput
            value={destination}
            onChangeText={setDestination}
            placeholder="Ex. Chamonix"
            placeholderTextColor={palette.textFaint}
            style={inputStyle}
            maxLength={120}
          />
        </View>

        <View
          style={{
            backgroundColor: palette.accentSoft,
            borderRadius: radius.md,
            padding: spacing.md,
            borderWidth: 1,
            borderColor: palette.accent + '40',
          }}
        >
          <Text variant="bodySmall" style={{ color: palette.accent }}>
            Un code unique sera généré automatiquement. Partagez-le à vos co-pilotes pour qu'ils
            rejoignent le convoi.
          </Text>
        </View>
      </View>

      <View style={{ gap: spacing.sm }}>
        <Button label="Créer le convoi" icon="convoy" onPress={handleCreate} loading={loading} />
        <Button label="Annuler" variant="ghost" onPress={() => router.back()} disabled={loading} />
      </View>
    </Screen>
  );
}
