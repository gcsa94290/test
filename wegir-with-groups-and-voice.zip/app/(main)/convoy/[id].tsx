import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';

import { Avatar, Badge, Button, Card, Icon, Screen, Text } from '@/components';
import { leaveConvoy } from '@/services/convoy/api';
import {
  connect,
  disconnect,
  joinConvoyRoom,
  leaveConvoyRoom,
  onConvoyUpdate,
  onVoiceSpeakers,
  startSpeaking,
  stopSpeaking,
} from '@/services/convoy/socket';
import { useConvoyStore } from '@/stores/convoy.store';
import { useTheme } from '@/theme';
import type { ConvoyMember } from '@/types/convoy';

// ── Helpers ──────────────────────────────────────────────────────────────────

function roleLabel(role: ConvoyMember['role']): string {
  return { leader: 'Leader', sweep: 'Serre-file', member: 'Membre' }[role];
}

function roleColor(role: ConvoyMember['role'], accent: string, amber: string, info: string): string {
  return { leader: accent, sweep: amber, member: info }[role];
}

function presenceColor(
  presence: ConvoyMember['presence'],
  success: string,
  amber: string,
  danger: string,
  muted: string,
): string {
  return (
    { live: success, lagging: amber, stopped: danger, offline: muted, detached: danger }[
      presence
    ] ?? muted
  );
}

// ── Push-to-talk button ───────────────────────────────────────────────────────

function VoiceButton({
  convoyId,
  activeSpeakers,
  currentUserId,
}: {
  convoyId: string;
  activeSpeakers: string[];
  currentUserId: string | undefined;
}) {
  const { palette, spacing, radius } = useTheme();
  const isPressing = useRef(false);

  const isSpeaking = activeSpeakers.includes(currentUserId ?? '');
  const otherSpeakers = activeSpeakers.filter((id) => id !== currentUserId);
  const someOneSpeaking = activeSpeakers.length > 0;

  function handlePressIn() {
    isPressing.current = true;
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    startSpeaking(convoyId);
  }

  function handlePressOut() {
    if (!isPressing.current) return;
    isPressing.current = false;
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    stopSpeaking(convoyId);
  }

  return (
    <View style={{ alignItems: 'center', gap: spacing.sm }}>
      {/* Speaker count badge */}
      {someOneSpeaking && !isSpeaking && (
        <Text variant="bodySmall" style={{ color: palette.amber }}>
          {otherSpeakers.length === 1 ? '1 membre parle…' : `${otherSpeakers.length} membres parlent…`}
        </Text>
      )}

      <Pressable
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        style={({ pressed }) => [
          styles.pttButton,
          {
            backgroundColor: isSpeaking
              ? palette.accent
              : pressed
                ? palette.surfaceHigh
                : palette.surface,
            borderColor: isSpeaking ? palette.accent : palette.border,
            borderRadius: radius.pill,
            width: 80,
            height: 80,
          },
        ]}
      >
        <Icon
          name="navigation"
          size={32}
          color={isSpeaking ? palette.onAccent : palette.textMuted}
        />
      </Pressable>

      <Text variant="label" style={{ color: palette.textFaint }}>
        {isSpeaking ? 'PARLER…' : 'APPUYER POUR PARLER'}
      </Text>
    </View>
  );
}

// ── Member row ────────────────────────────────────────────────────────────────

function MemberRow({
  member,
  isSpeaking,
}: {
  member: ConvoyMember;
  isSpeaking: boolean;
}) {
  const { palette, spacing } = useTheme();
  const rc = roleColor(member.role, palette.accent, palette.amber, palette.info);
  const pc = presenceColor(
    member.presence,
    palette.success,
    palette.amber,
    palette.danger,
    palette.textFaint,
  );

  return (
    <View
      style={[
        styles.memberRow,
        {
          paddingVertical: spacing.sm,
          paddingHorizontal: spacing.md,
          borderBottomWidth: 1,
          borderBottomColor: palette.border,
          backgroundColor: isSpeaking ? palette.accent + '12' : 'transparent',
        },
      ]}
    >
      <View style={{ position: 'relative' }}>
        <Avatar name={member.displayName} color={member.color} size={40} />
        {/* Presence dot */}
        <View
          style={[
            styles.presenceDot,
            { backgroundColor: pc, borderColor: palette.bgElevated },
          ]}
        />
        {/* Speaking indicator */}
        {isSpeaking && (
          <View
            style={[
              styles.speakingRing,
              { borderColor: palette.accent },
            ]}
          />
        )}
      </View>

      <View style={{ flex: 1, marginLeft: spacing.md }}>
        <View style={styles.row}>
          <Text variant="bodyStrong" style={{ color: palette.textPrimary }}>
            {member.displayName}
          </Text>
          {isSpeaking && (
            <Icon name="navigation" size={14} color={palette.accent} />
          )}
        </View>
        <View style={[styles.row, { gap: spacing.xs }]}>
          <Badge label={roleLabel(member.role)} color={rc} />
          {member.batteryLevel !== null && (
            <Text variant="overline" style={{ color: palette.textFaint }}>
              🔋 {member.batteryLevel}%
            </Text>
          )}
          {member.distanceToLeaderMeters !== null && member.distanceToLeaderMeters > 0 && (
            <Text variant="overline" style={{ color: palette.textFaint }}>
              {member.distanceToLeaderMeters < 1000
                ? `${member.distanceToLeaderMeters}m`
                : `${(member.distanceToLeaderMeters / 1000).toFixed(1)}km`}
            </Text>
          )}
        </View>
      </View>

      <View
        style={{
          width: 8,
          height: 8,
          borderRadius: 4,
          backgroundColor: pc,
        }}
      />
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────

export default function ConvoyDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { palette, spacing } = useTheme();

  const convoy = useConvoyStore((s) => s.activeConvoy);
  const activeSpeakers = useConvoyStore((s) => s.activeSpeakers);
  const updateConvoy = useConvoyStore((s) => s.updateConvoy);
  const setActiveSpeakers = useConvoyStore((s) => s.setActiveSpeakers);
  const setActiveConvoy = useConvoyStore((s) => s.setActiveConvoy);

  const [leaving, setLeaving] = useState(false);
  const [codeCopied, setCodeCopied] = useState(false);

  // Determine current user (first LEADER in members for now)
  const currentUserId = convoy?.members.find((m) => m.role === 'leader')?.id;

  // Socket lifecycle
  useEffect(() => {
    if (!id) return;

    // TODO: replace '' with real JWT from auth store
    connect('');
    joinConvoyRoom(id);

    const offConvoy = onConvoyUpdate((updated) => updateConvoy(updated));
    const offSpeakers = onVoiceSpeakers((speakers) => setActiveSpeakers(speakers));

    return () => {
      offConvoy();
      offSpeakers();
      leaveConvoyRoom(id);
    };
  }, [id]);

  async function handleCopyCode() {
    if (!convoy?.code) return;
    await Clipboard.setStringAsync(convoy.code);
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  }

  async function handleLeave() {
    Alert.alert('Quitter le convoi', 'Voulez-vous vraiment quitter ce convoi ?', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Quitter',
        style: 'destructive',
        onPress: async () => {
          if (!id) return;
          setLeaving(true);
          try {
            await leaveConvoy(id);
            disconnect();
            setActiveConvoy(null);
            router.replace('/(main)/convoy');
          } catch (e) {
            Alert.alert('Erreur', e instanceof Error ? e.message : 'Impossible de quitter.');
          } finally {
            setLeaving(false);
          }
        },
      },
    ]);
  }

  if (!convoy) {
    return (
      <Screen title="Convoi">
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.md }}>
          <Icon name="convoy" size={48} color={palette.textFaint} />
          <Text variant="body" style={{ color: palette.textMuted, textAlign: 'center' }}>
            Convoi introuvable. Il a peut-être pris fin.
          </Text>
          <Button label="Retour" variant="ghost" onPress={() => router.replace('/(main)/convoy')} />
        </View>
      </Screen>
    );
  }

  const memberCount = convoy.members.length;

  return (
    <Screen title={convoy.name} padded={false}>
      <ScrollView contentContainerStyle={{ paddingBottom: 16 }}>
        {/* Header card */}
        <View
          style={{
            backgroundColor: palette.bgElevated,
            borderBottomWidth: 1,
            borderBottomColor: palette.border,
            padding: spacing.lg,
            gap: spacing.md,
          }}
        >
          {/* Destination */}
          {convoy.destinationName ? (
            <View style={[styles.row, { gap: spacing.sm }]}>
              <Icon name="route" size={18} color={palette.textMuted} />
              <Text variant="body" style={{ color: palette.textSecondary }}>
                {convoy.destinationName}
              </Text>
            </View>
          ) : null}

          {/* Stats */}
          <View style={[styles.row, { gap: spacing.lg }]}>
            <View style={styles.row}>
              <Icon name="convoy" size={16} color={palette.accent} />
              <Text variant="bodySmall" style={{ color: palette.textSecondary, marginLeft: 4 }}>
                {memberCount} membre{memberCount > 1 ? 's' : ''}
              </Text>
            </View>
            <Badge
              label={convoy.members.filter((m) => m.presence === 'live').length + ' EN LIVE'}
              color={palette.success}
            />
          </View>

          {/* Code to share */}
          <Pressable
            onPress={handleCopyCode}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: spacing.sm,
              backgroundColor: palette.accentSoft,
              borderRadius: 10,
              paddingVertical: spacing.sm,
              paddingHorizontal: spacing.md,
              borderWidth: 1,
              borderColor: palette.accent + '40',
            }}
          >
            <Text
              variant="title"
              style={{ flex: 1, color: palette.accent, letterSpacing: 6 }}
            >
              {convoy.code}
            </Text>
            <Icon name="share" size={18} color={palette.accent} />
            {codeCopied && (
              <Text variant="label" style={{ color: palette.success }}>
                Copié !
              </Text>
            )}
          </Pressable>
        </View>

        {/* Members list */}
        <View style={{ padding: spacing.lg }}>
          <Text
            variant="label"
            style={{ color: palette.textMuted, marginBottom: spacing.md }}
          >
            MEMBRES
          </Text>
          <Card padded={false}>
            {convoy.members.map((member) => (
              <MemberRow
                key={member.id}
                member={member}
                isSpeaking={activeSpeakers.includes(member.id)}
              />
            ))}
          </Card>
        </View>

        {/* Voice channel */}
        <View style={{ paddingHorizontal: spacing.lg }}>
          <Text
            variant="label"
            style={{ color: palette.textMuted, marginBottom: spacing.md }}
          >
            CANAL VOCAL
          </Text>
          <Card>
            <VoiceButton
              convoyId={convoy.id}
              activeSpeakers={activeSpeakers}
              currentUserId={currentUserId}
            />
          </Card>
        </View>

        {/* Actions */}
        <View style={{ padding: spacing.lg, gap: spacing.sm }}>
          <Button
            label="Quitter le convoi"
            variant="danger"
            icon="alert"
            onPress={handleLeave}
            loading={leaving}
          />
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center' },
  memberRow: { flexDirection: 'row', alignItems: 'center' },
  presenceDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
  },
  speakingRing: {
    position: 'absolute',
    inset: -3,
    borderRadius: 24,
    borderWidth: 2,
  },
  pttButton: {
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
  },
});
