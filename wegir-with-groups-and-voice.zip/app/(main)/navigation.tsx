import { EmptyState, Screen } from '@/components';

export default function Navigation() {
  return (
    <Screen title="Navigation">
      <EmptyState
        icon="navigation"
        title="HUD de guidage en Phase 1"
        description="Vitesse, limite, ETA, manœuvre suivante et voies s'afficheront en plein écran."
      />
    </Screen>
  );
}
