import { Tabs } from 'expo-router';

import { Icon, type IconName } from '@/components';
import { useTheme } from '@/theme';

const TABS: { name: string; title: string; icon: IconName }[] = [
  { name: 'home', title: 'Accueil', icon: 'map' },
  { name: 'navigation', title: 'Nav', icon: 'navigation' },
  { name: 'convoy/index', title: 'Convoi', icon: 'convoy' },
  { name: 'profile', title: 'Profil', icon: 'profile' },
];

// Routes that exist in this group but must not appear as tabs.
const HIDDEN = ['settings', 'convoy/create', 'convoy/join', 'convoy/[id]', 'replay/[tripId]'];

export default function MainLayout() {
  const { palette, spacing } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: palette.accent,
        tabBarInactiveTintColor: palette.textMuted,
        tabBarStyle: {
          backgroundColor: palette.bgElevated,
          borderTopColor: palette.border,
          paddingTop: spacing.xs,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      }}
    >
      {TABS.map((tab) => (
        <Tabs.Screen
          key={tab.name}
          name={tab.name}
          options={{
            title: tab.title,
            tabBarIcon: ({ color, focused }) => (
              <Icon name={tab.icon} size={24} color={color} strokeWidth={focused ? 2.4 : 2} />
            ),
          }}
        />
      ))}
      {HIDDEN.map((name) => (
        <Tabs.Screen key={name} name={name} options={{ href: null }} />
      ))}
    </Tabs>
  );
}
