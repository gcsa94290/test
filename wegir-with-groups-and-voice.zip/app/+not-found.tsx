import { Link, Stack } from 'expo-router';

import { Screen, EmptyState, Text } from '@/components';

export default function NotFound() {
  return (
    <>
      <Stack.Screen options={{ title: 'Introuvable' }} />
      <Screen>
        <EmptyState
          icon="alert"
          title="Page introuvable"
          description="Cette destination n'existe pas."
        />
        <Link href="/" style={{ alignSelf: 'center', marginTop: 16 }}>
          <Text variant="bodyStrong" color="accent">
            Retour à l'accueil
          </Text>
        </Link>
      </Screen>
    </>
  );
}
