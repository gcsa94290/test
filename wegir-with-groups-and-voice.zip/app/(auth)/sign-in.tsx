import { useRouter } from 'expo-router';

import { Button, EmptyState, Screen } from '@/components';

export default function SignIn() {
  const router = useRouter();
  return (
    <Screen title="Se connecter">
      <EmptyState
        icon="profile"
        title="Connexion"
        description="Firebase Auth est branché en Phase 2 (email, lien, et compte invité)."
      />
      <Button
        label="Créer un compte"
        variant="ghost"
        onPress={() => router.push('/(auth)/sign-up')}
      />
    </Screen>
  );
}
