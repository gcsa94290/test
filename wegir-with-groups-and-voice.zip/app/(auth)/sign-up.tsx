import { EmptyState, Screen } from '@/components';

export default function SignUp() {
  return (
    <Screen title="Créer un compte">
      <EmptyState
        icon="profile"
        title="Inscription"
        description="Le formulaire et la création de compte Firebase arrivent en Phase 2."
      />
    </Screen>
  );
}
