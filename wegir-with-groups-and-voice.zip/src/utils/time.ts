export function arrivalTime(durationSeconds: number, from: number = Date.now()): string {
  const date = new Date(from + durationSeconds * 1000);
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

export function minutesUntil(timestamp: number, from: number = Date.now()): number {
  return Math.max(0, Math.round((timestamp - from) / 60000));
}

export function randomId(prefix = ''): string {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

export function groupCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i += 1) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}
