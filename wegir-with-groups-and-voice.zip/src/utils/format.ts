export function formatDistance(meters: number | null): string {
  if (meters == null) return '--';
  if (meters < 1000) return `${Math.round(meters)} m`;
  return `${(meters / 1000).toFixed(meters < 10000 ? 1 : 0)} km`;
}

export function formatSpeed(speedMs: number | null): number {
  if (speedMs == null || speedMs < 0) return 0;
  return Math.round(speedMs * 3.6);
}

export function formatDuration(seconds: number | null): string {
  if (seconds == null) return '--';
  const total = Math.round(seconds / 60);
  const hours = Math.floor(total / 60);
  const mins = total % 60;
  if (hours === 0) return `${mins} min`;
  return `${hours} h ${String(mins).padStart(2, '0')}`;
}
