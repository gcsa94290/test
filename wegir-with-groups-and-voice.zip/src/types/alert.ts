import type { Coordinates } from './route';

export type AlertType =
  | 'accident'
  | 'traffic'
  | 'roadwork'
  | 'road-closed'
  | 'detour'
  | 'hazard'
  | 'stopped-vehicle'
  | 'pothole'
  | 'slippery'
  | 'flood'
  | 'fog'
  | 'police'
  | 'broken-light'
  | 'protest';

export interface Alert {
  id: string;
  type: AlertType;
  // Police is reported as a fuzzy zone, never an exact point.
  location: Coordinates;
  fuzzyRadiusMeters: number;
  authorId: string;
  authorName: string;
  createdAt: number;
  expiresAt: number;
  confirmations: number;
  denials: number;
}

export interface AlertVote {
  alertId: string;
  voterId: string;
  kind: 'confirm' | 'deny';
}
