export interface User {
  id: string;
  displayName: string;
  email: string | null;
  photoColor: string;
  contributionPoints: number;
}

export interface AuthSession {
  user: User | null;
  status: 'loading' | 'authenticated' | 'anonymous';
}
