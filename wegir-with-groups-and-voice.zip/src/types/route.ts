export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface GeoPosition extends Coordinates {
  heading: number | null;
  speed: number | null;
  accuracy: number | null;
  timestamp: number;
}

export type ManeuverType =
  | 'turn-left'
  | 'turn-right'
  | 'straight'
  | 'merge'
  | 'roundabout'
  | 'arrive';

export interface Maneuver {
  type: ManeuverType;
  instruction: string;
  distanceMeters: number;
  road?: string;
}

export interface RoutePlan {
  distanceMeters: number;
  durationSeconds: number;
  geometry: Coordinates[];
  maneuvers: Maneuver[];
}

export interface RoutePreferences {
  avoidTolls: boolean;
  avoidMotorways: boolean;
  avoidFerries: boolean;
  vehicle: 'car' | 'motorcycle';
}
