import type { GeoPosition } from './route';

export type MemberRole = 'leader' | 'sweep' | 'member';
export type MemberPresence = 'live' | 'lagging' | 'stopped' | 'offline';

export interface ConvoyMember {
  id: string;
  displayName: string;
  color: string;
  role: MemberRole;
  presence: MemberPresence;
  position: GeoPosition | null;
  distanceToLeaderMeters: number | null;
  batteryLevel: number | null;
  fuelLevel: number | null;
  isSelf: boolean;
}

export interface Convoy {
  id: string;
  code: string;
  name: string;
  leaderId: string;
  destinationName: string | null;
  members: ConvoyMember[];
  createdAt: number;
}
