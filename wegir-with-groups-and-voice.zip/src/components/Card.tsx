import type { ReactNode } from 'react';
import { View, type ViewStyle } from 'react-native';

import { useTheme } from '@/theme';

interface CardProps {
  children: ReactNode;
  padded?: boolean;
  style?: ViewStyle;
}

export function Card({ children, padded = true, style }: CardProps) {
  const { palette, radius, spacing } = useTheme();
  return (
    <View
      style={[
        {
          backgroundColor: palette.bgElevated,
          borderRadius: radius.lg,
          borderWidth: 1,
          borderColor: palette.border,
          padding: padded ? spacing.lg : 0,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}
