import { Text as RNText, type TextProps as RNTextProps } from 'react-native';

import { useTheme, type TypographyToken, type TextStyleToken } from '@/theme';

type ColorToken = 'primary' | 'secondary' | 'muted' | 'faint' | 'accent' | 'danger';

interface TextProps extends RNTextProps {
  variant?: TypographyToken;
  color?: ColorToken;
}

export function Text({ variant = 'body', color = 'primary', style, ...rest }: TextProps) {
  const theme = useTheme();
  const token: TextStyleToken = theme.typography[variant];

  const colorMap: Record<ColorToken, string> = {
    primary: theme.palette.textPrimary,
    secondary: theme.palette.textSecondary,
    muted: theme.palette.textMuted,
    faint: theme.palette.textFaint,
    accent: theme.palette.accent,
    danger: theme.palette.danger,
  };

  return (
    <RNText
      style={[
        {
          color: colorMap[color],
          fontSize: token.fontSize,
          lineHeight: token.lineHeight,
          fontWeight: token.fontWeight,
          letterSpacing: token.letterSpacing,
          fontFamily: token.fontFamily ?? theme.fontFamily.sans,
        },
        style,
      ]}
      {...rest}
    />
  );
}
