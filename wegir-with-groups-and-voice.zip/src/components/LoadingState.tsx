import { ActivityIndicator, View } from 'react-native';

import { useTheme } from '@/theme';

import { Text } from './Text';

interface LoadingStateProps {
  label?: string;
}

export function LoadingState({ label }: LoadingStateProps) {
  const { palette, spacing } = useTheme();
  return (
    <View
      style={{
        alignItems: 'center',
        justifyContent: 'center',
        padding: spacing.xl,
        gap: spacing.md,
      }}
    >
      <ActivityIndicator color={palette.accent} />
      {label ? (
        <Text variant="label" color="muted">
          {label}
        </Text>
      ) : null}
    </View>
  );
}
