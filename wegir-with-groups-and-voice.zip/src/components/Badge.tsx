import { View } from 'react-native';

import { useTheme } from '@/theme';

import { Text } from './Text';

interface BadgeProps {
  label: string;
  color?: string;
}

export function Badge({ label, color }: BadgeProps) {
  const { palette, radius, spacing } = useTheme();
  const tint = color ?? palette.accent;

  return (
    <View
      style={{
        alignSelf: 'flex-start',
        backgroundColor: tint + '22',
        borderRadius: radius.sm,
        paddingHorizontal: spacing.sm,
        paddingVertical: 2,
      }}
    >
      <Text variant="overline" style={{ color: tint }}>
        {label.toUpperCase()}
      </Text>
    </View>
  );
}
