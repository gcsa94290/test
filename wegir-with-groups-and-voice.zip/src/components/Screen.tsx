import type { ReactNode } from 'react';
import { View, type ViewStyle } from 'react-native';
import { SafeAreaView, type Edge } from 'react-native-safe-area-context';

import { useTheme } from '@/theme';

import { Text } from './Text';

interface ScreenProps {
  children?: ReactNode;
  title?: string;
  edges?: Edge[];
  padded?: boolean;
  style?: ViewStyle;
}

export function Screen({
  children,
  title,
  edges = ['top', 'bottom'],
  padded = true,
  style,
}: ScreenProps) {
  const { palette, spacing } = useTheme();
  return (
    <SafeAreaView edges={edges} style={{ flex: 1, backgroundColor: palette.bgBase }}>
      <View style={[{ flex: 1, padding: padded ? spacing.lg : 0 }, style]}>
        {title ? (
          <Text variant="title" style={{ marginBottom: spacing.lg }}>
            {title}
          </Text>
        ) : null}
        {children}
      </View>
    </SafeAreaView>
  );
}
