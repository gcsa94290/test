import type { ReactElement } from 'react';
import { Circle, Line, Path } from 'react-native-svg';

// Every glyph is hand-drawn on a 24x24 grid, stroke-based to match the HUD aesthetic.
// Stroke, width and line joins are inherited from the parent <Svg> in Icon.tsx.
// Filled dots set their own fill explicitly.

export const glyphs = {
  map: (
    <>
      <Path d="M3 6 L9 4 L15 6 L21 4 V18 L15 20 L9 18 L3 20 Z" />
      <Line x1="9" y1="4" x2="9" y2="18" />
      <Line x1="15" y1="6" x2="15" y2="20" />
    </>
  ),

  navigation: <Path d="M21 3 L3 10.5 L11 12.8 L13.4 21 Z" />,

  convoy: (
    <>
      <Circle cx="9" cy="8" r="3" />
      <Path d="M3.5 20 a5.5 5.5 0 0 1 11 0" />
      <Circle cx="17" cy="9" r="2.4" />
      <Path d="M15.5 16.4 a4.6 4.6 0 0 1 5.5 3.6" />
    </>
  ),

  alert: (
    <>
      <Path d="M12 4 L22 20 L2 20 Z" />
      <Line x1="12" y1="10" x2="12" y2="15" />
      <Circle cx="12" cy="17.6" r="0.7" fill="currentColor" stroke="none" />
    </>
  ),

  search: (
    <>
      <Circle cx="11" cy="11" r="7" />
      <Line x1="16.2" y1="16.2" x2="21" y2="21" />
    </>
  ),

  profile: (
    <>
      <Circle cx="12" cy="8" r="4" />
      <Path d="M5 20 a7 7 0 0 1 14 0" />
    </>
  ),

  settings: (
    <>
      <Line x1="4" y1="7" x2="20" y2="7" />
      <Line x1="4" y1="12" x2="20" y2="12" />
      <Line x1="4" y1="17" x2="20" y2="17" />
      <Circle cx="9" cy="7" r="2.2" fill="currentColor" />
      <Circle cx="15" cy="12" r="2.2" fill="currentColor" />
      <Circle cx="8" cy="17" r="2.2" fill="currentColor" />
    </>
  ),

  chevronRight: <Path d="M9 5 L16 12 L9 19" />,
  chevronLeft: <Path d="M15 5 L8 12 L15 19" />,
  close: (
    <>
      <Line x1="6" y1="6" x2="18" y2="18" />
      <Line x1="18" y1="6" x2="6" y2="18" />
    </>
  ),
  check: <Path d="M5 13 L10 18 L19 6" />,
  plus: (
    <>
      <Line x1="12" y1="5" x2="12" y2="19" />
      <Line x1="5" y1="12" x2="19" y2="12" />
    </>
  ),

  recenter: (
    <>
      <Circle cx="12" cy="12" r="6" />
      <Circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" />
      <Line x1="12" y1="2" x2="12" y2="5" />
      <Line x1="12" y1="19" x2="12" y2="22" />
      <Line x1="2" y1="12" x2="5" y2="12" />
      <Line x1="19" y1="12" x2="22" y2="12" />
    </>
  ),

  mic: (
    <>
      <Path d="M9 5 a3 3 0 0 1 6 0 V12 a3 3 0 0 1 -6 0 Z" />
      <Path d="M5 11 a7 7 0 0 0 14 0" />
      <Line x1="12" y1="18" x2="12" y2="22" />
      <Line x1="8" y1="22" x2="16" y2="22" />
    </>
  ),

  bell: (
    <>
      <Path d="M6 10 a6 6 0 0 1 12 0 c0 5 1.6 6 1.6 6 H4.4 s1.6 -1 1.6 -6 Z" />
      <Path d="M10.2 20 a2 2 0 0 0 3.6 0" />
    </>
  ),

  fuel: (
    <>
      <Path d="M5 21 V6 a2 2 0 0 1 2 -2 H11 a2 2 0 0 1 2 2 V21" />
      <Line x1="3" y1="21" x2="15" y2="21" />
      <Line x1="6.5" y1="9" x2="11.5" y2="9" />
      <Path d="M13 8 H16 a1.8 1.8 0 0 1 1.8 1.8 V15 a1.6 1.6 0 0 0 3.2 0 V9 L18 5.5" />
    </>
  ),

  sos: (
    <>
      <Path d="M12 3 L20 6 V11 c0 5 -3.4 8 -8 10 c-4.6 -2 -8 -5 -8 -10 V6 Z" />
      <Line x1="12" y1="8.5" x2="12" y2="13" />
      <Circle cx="12" cy="16" r="0.7" fill="currentColor" stroke="none" />
    </>
  ),

  route: (
    <>
      <Circle cx="6" cy="18" r="2.2" />
      <Circle cx="18" cy="6" r="2.2" />
      <Path d="M6 15.6 V12 a3 3 0 0 1 3 -3 H15 a3 3 0 0 0 3 -3" strokeDasharray="0.1 3.6" />
    </>
  ),

  qr: (
    <>
      <Path d="M4 9 V4 H9" />
      <Path d="M15 4 H20 V9" />
      <Path d="M4 15 V20 H9" />
      <Path d="M20 14 V20 H14" />
      <Circle cx="6.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
      <Circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
      <Circle cx="6.5" cy="17.5" r="1" fill="currentColor" stroke="none" />
    </>
  ),

  car: (
    <>
      <Path d="M3 13 L5.2 7.6 a2 2 0 0 1 1.9 -1.3 H16.9 a2 2 0 0 1 1.9 1.3 L21 13 V17.5 H3 Z" />
      <Circle cx="7" cy="17.5" r="1.6" fill="currentColor" stroke="none" />
      <Circle cx="17" cy="17.5" r="1.6" fill="currentColor" stroke="none" />
      <Line x1="3" y1="13" x2="21" y2="13" />
    </>
  ),

  speed: (
    <>
      <Path d="M4 18 a8 8 0 1 1 16 0" />
      <Line x1="12" y1="14" x2="16" y2="9" />
      <Circle cx="12" cy="14" r="1.4" fill="currentColor" stroke="none" />
    </>
  ),

  clock: (
    <>
      <Circle cx="12" cy="12" r="8" />
      <Path d="M12 7 V12 L15.5 14" />
    </>
  ),

  share: (
    <>
      <Circle cx="6" cy="12" r="2.4" />
      <Circle cx="18" cy="6" r="2.4" />
      <Circle cx="18" cy="18" r="2.4" />
      <Line x1="8.1" y1="10.9" x2="15.9" y2="7.1" />
      <Line x1="8.1" y1="13.1" x2="15.9" y2="16.9" />
    </>
  ),

  turnRight: <Path d="M8 20 V11 a4 4 0 0 1 4 -4 H17 M13 3 L18 7 L13 11" />,
} satisfies Record<string, ReactElement>;

export type IconName = keyof typeof glyphs;

export const iconNames = Object.keys(glyphs) as IconName[];
