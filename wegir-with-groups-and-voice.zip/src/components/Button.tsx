import { ActivityIndicator, Pressable, StyleSheet, View, type ViewStyle } from 'react-native';

import { useTheme } from '@/theme';

import { Icon, type IconName } from './icons';
import { Text } from './Text';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

interface ButtonProps {
  label: string;
  onPress?: () => void;
  variant?: Variant;
  icon?: IconName;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
}

export function Button({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled,
  loading,
  style,
}: ButtonProps) {
  const theme = useTheme();
  const { palette, radius, spacing, tapTarget } = theme;

  const bg: Record<Variant, string> = {
    primary: palette.accent,
    secondary: palette.surfaceHigh,
    ghost: 'transparent',
    danger: palette.danger,
  };
  const fg: Record<Variant, string> = {
    primary: palette.onAccent,
    secondary: palette.textPrimary,
    ghost: palette.accent,
    danger: '#ffffff',
  };

  const inactive = disabled || loading;

  return (
    <Pressable
      onPress={onPress}
      disabled={inactive}
      style={({ pressed }) => [
        styles.base,
        {
          minHeight: tapTarget,
          borderRadius: radius.md,
          paddingHorizontal: spacing.xl,
          gap: spacing.sm,
          backgroundColor: bg[variant],
          borderWidth: variant === 'ghost' ? 1 : 0,
          borderColor: palette.borderStrong,
          opacity: inactive ? 0.45 : pressed ? 0.85 : 1,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg[variant]} />
      ) : (
        <View style={styles.row}>
          {icon ? <Icon name={icon} size={20} color={fg[variant]} /> : null}
          <Text variant="bodyStrong" style={{ color: fg[variant] }}>
            {label}
          </Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: { alignItems: 'center', justifyContent: 'center', flexDirection: 'row' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
});
