import { View } from 'react-native';

import { useTheme } from '@/theme';

import { Text } from './Text';

interface AvatarProps {
  name: string;
  color: string;
  size?: number;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).slice(0, 2);
  return parts.map((p) => p.charAt(0).toUpperCase()).join('');
}

export function Avatar({ name, color, size = 40 }: AvatarProps) {
  const { palette } = useTheme();
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: color + '22',
        borderWidth: 2,
        borderColor: color,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text variant="label" style={{ color: palette.textPrimary }}>
        {initials(name)}
      </Text>
    </View>
  );
}
