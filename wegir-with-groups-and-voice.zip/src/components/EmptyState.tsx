import { View } from 'react-native';

import { useTheme } from '@/theme';

import { Icon, type IconName } from './icons';
import { Text } from './Text';

interface EmptyStateProps {
  icon?: IconName;
  title: string;
  description?: string;
}

export function EmptyState({ icon, title, description }: EmptyStateProps) {
  const { palette, spacing } = useTheme();
  return (
    <View
      style={{
        alignItems: 'center',
        justifyContent: 'center',
        padding: spacing.xl,
        gap: spacing.md,
      }}
    >
      {icon ? <Icon name={icon} size={40} color={palette.textFaint} strokeWidth={1.6} /> : null}
      <Text variant="heading" style={{ textAlign: 'center' }}>
        {title}
      </Text>
      {description ? (
        <Text variant="body" color="muted" style={{ textAlign: 'center' }}>
          {description}
        </Text>
      ) : null}
    </View>
  );
}
