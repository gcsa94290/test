/**
 * Socket.IO client for convoy real-time updates and voice channel.
 * Usage: call connect() once the user joins a convoy, disconnect() when leaving.
 */

import { io as createSocketIo, type Socket } from 'socket.io-client';

import { socketUrl } from '@/lib/api';
import type { Convoy } from '@/types/convoy';

// ── Event constants (mirrors server/src/realtime/events.ts) ────────────────
export const SocketEvents = {
  JOIN_CONVOY: 'convoy:join',
  LEAVE_CONVOY: 'convoy:leave',
  POSITION_UPDATE: 'position:update',
  CONVOY_UPDATE: 'convoy:update',
  VOICE_START: 'voice:start',
  VOICE_STOP: 'voice:stop',
  VOICE_SIGNAL: 'voice:signal',
  VOICE_SPEAKERS: 'voice:speakers',
} as const;

type ConvoyUpdateCallback = (convoy: Convoy) => void;
type SpeakersCallback = (speakers: string[]) => void;
type SignalCallback = (payload: { fromUserId: string; [key: string]: unknown }) => void;

let socket: Socket | null = null;

export function getSocket(): Socket | null {
  return socket;
}

export function connect(token: string): Socket {
  if (socket?.connected) return socket;

  socket = createSocketIo(socketUrl, {
    auth: { token },
    transports: ['websocket'],
    autoConnect: true,
  });

  return socket;
}

export function disconnect(): void {
  socket?.disconnect();
  socket = null;
}

export function joinConvoyRoom(convoyId: string): void {
  socket?.emit(SocketEvents.JOIN_CONVOY, convoyId);
}

export function leaveConvoyRoom(convoyId: string): void {
  socket?.emit(SocketEvents.LEAVE_CONVOY, convoyId);
}

export function onConvoyUpdate(cb: ConvoyUpdateCallback): () => void {
  socket?.on(SocketEvents.CONVOY_UPDATE, cb);
  return () => socket?.off(SocketEvents.CONVOY_UPDATE, cb);
}

export function onVoiceSpeakers(cb: SpeakersCallback): () => void {
  const handler = (payload: { convoyId: string; speakers: string[] }) => cb(payload.speakers);
  socket?.on(SocketEvents.VOICE_SPEAKERS, handler);
  return () => socket?.off(SocketEvents.VOICE_SPEAKERS, handler);
}

export function onVoiceSignal(cb: SignalCallback): () => void {
  socket?.on(SocketEvents.VOICE_SIGNAL, cb);
  return () => socket?.off(SocketEvents.VOICE_SIGNAL, cb);
}

// ── Push-to-Talk ─────────────────────────────────────────────────────────────

export function startSpeaking(convoyId: string): void {
  socket?.emit(SocketEvents.VOICE_START, { convoyId });
}

export function stopSpeaking(convoyId: string): void {
  socket?.emit(SocketEvents.VOICE_STOP, { convoyId });
}

export function sendSignal(convoyId: string, signal: Record<string, unknown>): void {
  socket?.emit(SocketEvents.VOICE_SIGNAL, { convoyId, ...signal });
}
