/**
 * Convoy REST API client.
 * Wraps fetch calls against the Express server.
 */

import { apiBaseUrl } from '@/lib/api';
import type { Convoy } from '@/types/convoy';

// Minimal auth token store — in production this comes from your auth store/SecureStore.
let _accessToken: string | null = null;
export function setConvoyApiToken(token: string | null) {
  _accessToken = token;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(init?.headers as Record<string, string> | undefined),
  };
  if (_accessToken) {
    headers['Authorization'] = `Bearer ${_accessToken}`;
  }
  const res = await fetch(`${apiBaseUrl}/api${path}`, { ...init, headers });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${text}`);
  }
  return res.json() as Promise<T>;
}

export function createConvoy(name: string, destinationName?: string): Promise<Convoy> {
  return request<Convoy>('/convoys', {
    method: 'POST',
    body: JSON.stringify({ name, destinationName }),
  });
}

export function joinConvoy(code: string): Promise<Convoy> {
  return request<Convoy>('/convoys/join', {
    method: 'POST',
    body: JSON.stringify({ code }),
  });
}

export function getConvoy(id: string): Promise<Convoy> {
  return request<Convoy>(`/convoys/${id}`);
}

export function listMyConvoys(): Promise<Convoy[]> {
  return request<Convoy[]>('/convoys');
}

export function leaveConvoy(id: string): Promise<void> {
  return request<void>(`/convoys/${id}/leave`, { method: 'DELETE' });
}
