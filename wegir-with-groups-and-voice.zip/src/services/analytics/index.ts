type AnalyticsProps = Record<string, string | number | boolean>;

// Stub transport. Swap for a real provider later without touching call sites.
export function track(event: string, props?: AnalyticsProps): void {
  if (__DEV__) {
    console.log(`[analytics] ${event}`, props ?? {});
  }
}
