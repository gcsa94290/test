import type { GeoPosition } from '@/types';

import type { GeolocationService, PositionListener } from './types';

// Drives a slow loop around Annecy so the UI can run without GPS or a dev build.
const START = { latitude: 45.8992, longitude: 6.1294 };

export class MockGeolocation implements GeolocationService {
  private timer: ReturnType<typeof setInterval> | null = null;
  private step = 0;

  async requestPermission(): Promise<boolean> {
    return true;
  }

  private positionAt(step: number): GeoPosition {
    const angle = (step % 360) * (Math.PI / 180);
    return {
      latitude: START.latitude + Math.sin(angle) * 0.01,
      longitude: START.longitude + Math.cos(angle) * 0.01,
      heading: (step * 3) % 360,
      speed: 13.8,
      accuracy: 5,
      timestamp: Date.now(),
    };
  }

  async getCurrent(): Promise<GeoPosition | null> {
    return this.positionAt(this.step);
  }

  async start(onUpdate: PositionListener): Promise<void> {
    await this.stop();
    this.timer = setInterval(() => {
      this.step += 3;
      onUpdate(this.positionAt(this.step));
    }, 2000);
  }

  async stop(): Promise<void> {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
