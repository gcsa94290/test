import * as Location from 'expo-location';

import type { GeoPosition } from '@/types';

import type { GeolocationService, PositionListener } from './types';

function toPosition(raw: Location.LocationObject): GeoPosition {
  return {
    latitude: raw.coords.latitude,
    longitude: raw.coords.longitude,
    heading: raw.coords.heading,
    speed: raw.coords.speed,
    accuracy: raw.coords.accuracy,
    timestamp: raw.timestamp,
  };
}

// Foreground tracking only. Background tracking is added later behind the same
// interface using react-native-background-geolocation.
export class ExpoGeolocation implements GeolocationService {
  private subscription: Location.LocationSubscription | null = null;

  async requestPermission(): Promise<boolean> {
    const { status } = await Location.requestForegroundPermissionsAsync();
    return status === 'granted';
  }

  async getCurrent(): Promise<GeoPosition | null> {
    const raw = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
    return toPosition(raw);
  }

  async start(onUpdate: PositionListener): Promise<void> {
    await this.stop();
    this.subscription = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 2000, distanceInterval: 5 },
      (raw) => onUpdate(toPosition(raw)),
    );
  }

  async stop(): Promise<void> {
    this.subscription?.remove();
    this.subscription = null;
  }
}
