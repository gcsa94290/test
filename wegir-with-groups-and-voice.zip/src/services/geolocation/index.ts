import { config } from '@/constants/config';

import { ExpoGeolocation } from './expo';
import { MockGeolocation } from './mock';
import type { GeolocationService } from './types';

export const geolocation: GeolocationService = config.useMockLocation
  ? new MockGeolocation()
  : new ExpoGeolocation();

export type { GeolocationService, PositionListener } from './types';
