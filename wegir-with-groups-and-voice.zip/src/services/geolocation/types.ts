import type { GeoPosition } from '@/types';

export type PositionListener = (position: GeoPosition) => void;

export interface GeolocationService {
  requestPermission(): Promise<boolean>;
  getCurrent(): Promise<GeoPosition | null>;
  start(onUpdate: PositionListener): Promise<void>;
  stop(): Promise<void>;
}
