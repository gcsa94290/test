import { useColorScheme } from 'react-native';

import { useAppStore, type ThemePreference } from '@/stores/app.store';

import { darkPalette, lightPalette, type Palette } from './colors';
import { radius } from './radius';
import { shadows } from './shadows';
import { spacing, tapTarget } from './spacing';
import { fontFamily, fontWeight, typography } from './typography';

export interface Theme {
  palette: Palette;
  typography: typeof typography;
  spacing: typeof spacing;
  radius: typeof radius;
  shadows: typeof shadows;
  fontFamily: typeof fontFamily;
  fontWeight: typeof fontWeight;
  tapTarget: number;
}

function buildTheme(palette: Palette): Theme {
  return { palette, typography, spacing, radius, shadows, fontFamily, fontWeight, tapTarget };
}

function resolvePalette(preference: ThemePreference, system: 'dark' | 'light'): Palette {
  const mode = preference === 'system' ? system : preference;
  return mode === 'light' ? lightPalette : darkPalette;
}

export function useTheme(): Theme {
  const preference = useAppStore((s) => s.themePreference);
  const system = useColorScheme() ?? 'dark';
  return buildTheme(resolvePalette(preference, system));
}

export * from './colors';
export * from './typography';
export * from './spacing';
export * from './radius';
export * from './shadows';
