import { Platform, type ViewStyle } from 'react-native';

function shadow(elevation: number, opacity: number, radius: number, height: number): ViewStyle {
  return Platform.select<ViewStyle>({
    android: { elevation },
    default: {
      shadowColor: '#000000',
      shadowOpacity: opacity,
      shadowRadius: radius,
      shadowOffset: { width: 0, height },
    },
  });
}

export const shadows = {
  none: {} as ViewStyle,
  low: shadow(3, 0.25, 6, 2),
  medium: shadow(6, 0.35, 12, 4),
  high: shadow(12, 0.45, 24, 8),
} as const;

export type ShadowToken = keyof typeof shadows;
