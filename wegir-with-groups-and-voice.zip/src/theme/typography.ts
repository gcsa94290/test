import { Platform } from 'react-native';

const sans = Platform.select({ ios: 'System', android: 'sans-serif', default: 'System' });
const mono = Platform.select({
  ios: 'Menlo',
  android: 'monospace',
  default: 'monospace',
});

export const fontFamily = {
  sans,
  mono,
} as const;

export const fontWeight = {
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
} as const;

export interface TextStyleToken {
  fontSize: number;
  lineHeight: number;
  fontWeight: (typeof fontWeight)[keyof typeof fontWeight];
  letterSpacing?: number;
  fontFamily?: string;
}

export const typography = {
  display: { fontSize: 40, lineHeight: 44, fontWeight: fontWeight.bold, letterSpacing: -0.5 },
  title: { fontSize: 28, lineHeight: 34, fontWeight: fontWeight.bold, letterSpacing: -0.3 },
  heading: { fontSize: 20, lineHeight: 26, fontWeight: fontWeight.semibold },
  body: { fontSize: 16, lineHeight: 22, fontWeight: fontWeight.regular },
  bodyStrong: { fontSize: 16, lineHeight: 22, fontWeight: fontWeight.semibold },
  label: { fontSize: 14, lineHeight: 18, fontWeight: fontWeight.medium },
  caption: { fontSize: 12, lineHeight: 16, fontWeight: fontWeight.medium },
  overline: {
    fontSize: 11,
    lineHeight: 14,
    fontWeight: fontWeight.semibold,
    letterSpacing: 1.2,
  },
  hudValue: {
    fontSize: 52,
    lineHeight: 56,
    fontWeight: fontWeight.bold,
    fontFamily: mono,
    letterSpacing: -1,
  },
} satisfies Record<string, TextStyleToken>;

export type TypographyToken = keyof typeof typography;
