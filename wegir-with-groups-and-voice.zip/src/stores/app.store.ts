import { create } from 'zustand';

export type ThemePreference = 'system' | 'dark' | 'light';

interface AppState {
  themePreference: ThemePreference;
  hasCompletedOnboarding: boolean;

  setThemePreference: (preference: ThemePreference) => void;
  completeOnboarding: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  themePreference: 'system',
  hasCompletedOnboarding: false,

  setThemePreference: (themePreference) => set({ themePreference }),
  completeOnboarding: () => set({ hasCompletedOnboarding: true }),
}));
