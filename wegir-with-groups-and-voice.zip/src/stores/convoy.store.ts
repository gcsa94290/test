import { create } from 'zustand';

import type { Convoy } from '@/types/convoy';

interface ConvoyState {
  activeConvoy: Convoy | null;
  activeSpeakers: string[]; // userIds currently speaking
  setActiveConvoy: (convoy: Convoy | null) => void;
  updateConvoy: (convoy: Convoy) => void;
  setActiveSpeakers: (speakers: string[]) => void;
}

export const useConvoyStore = create<ConvoyState>((set) => ({
  activeConvoy: null,
  activeSpeakers: [],
  setActiveConvoy: (activeConvoy) => set({ activeConvoy }),
  updateConvoy: (convoy) => set({ activeConvoy: convoy }),
  setActiveSpeakers: (activeSpeakers) => set({ activeSpeakers }),
}));
