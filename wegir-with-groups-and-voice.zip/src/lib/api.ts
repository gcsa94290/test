// Base config for the Node/Express + MySQL API. The full fetch client
// (auth interceptors, refresh, error handling) is added with the API client task.
export const apiBaseUrl = process.env.EXPO_PUBLIC_API_URL ?? '';
export const socketUrl = process.env.EXPO_PUBLIC_SOCKET_URL ?? apiBaseUrl;

export function isApiConfigured(): boolean {
  return apiBaseUrl.length > 0;
}
