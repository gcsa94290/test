const token = process.env.EXPO_PUBLIC_MAPBOX_TOKEN ?? '';

export function isMapboxConfigured(): boolean {
  return token.length > 0;
}

// The native module is required lazily so the app still runs in Expo Go
// (where @rnmapbox/maps is absent) until a token is provided and a dev build is used.
export function configureMapbox(): void {
  if (!isMapboxConfigured()) return;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const Mapbox = require('@rnmapbox/maps').default as { setAccessToken: (t: string) => void };
  Mapbox.setAccessToken(token);
}

export const mapStyles = {
  night: 'mapbox://styles/mapbox/navigation-night-v1',
  day: 'mapbox://styles/mapbox/navigation-day-v1',
} as const;
