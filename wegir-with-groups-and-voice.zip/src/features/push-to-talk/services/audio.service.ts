export type ChannelState = 'idle' | 'connecting' | 'connected' | 'error';
export type SpeakerListener = (speakerId: string | null) => void;

// Real-time voice transport. The LiveKit implementation lands in Phase 5
// behind this interface so the UI can be built against the mock first.
export interface AudioService {
  connect(channelId: string): Promise<void>;
  disconnect(): Promise<void>;
  startSpeaking(): void;
  stopSpeaking(): void;
  onSpeakerChange(listener: SpeakerListener): () => void;
  getState(): ChannelState;
}

export class MockAudioService implements AudioService {
  private state: ChannelState = 'idle';
  private listeners = new Set<SpeakerListener>();

  async connect(): Promise<void> {
    this.state = 'connected';
  }

  async disconnect(): Promise<void> {
    this.state = 'idle';
  }

  startSpeaking(): void {
    this.listeners.forEach((l) => l('self'));
  }

  stopSpeaking(): void {
    this.listeners.forEach((l) => l(null));
  }

  onSpeakerChange(listener: SpeakerListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  getState(): ChannelState {
    return this.state;
  }
}

export const audioService: AudioService = new MockAudioService();
