import { useState } from 'react';

import { geolocation } from '@/services/geolocation';
import { requestNotificationPermission } from '@/services/notifications';

type Status = 'pending' | 'granted' | 'denied';

export function usePermissions() {
  const [location, setLocation] = useState<Status>('pending');
  const [notifications, setNotifications] = useState<Status>('pending');

  const requestLocation = async () => {
    const granted = await geolocation.requestPermission();
    setLocation(granted ? 'granted' : 'denied');
    return granted;
  };

  const requestNotifications = async () => {
    const granted = await requestNotificationPermission();
    setNotifications(granted ? 'granted' : 'denied');
    return granted;
  };

  return { location, notifications, requestLocation, requestNotifications };
}
