import { Pressable, View } from 'react-native';

import { Icon, Text, type IconName } from '@/components';
import { useTheme } from '@/theme';

interface PermissionRowProps {
  icon: IconName;
  title: string;
  description: string;
  granted: boolean;
  onRequest: () => void;
}

export function PermissionRow({
  icon,
  title,
  description,
  granted,
  onRequest,
}: PermissionRowProps) {
  const { palette, spacing, tapTarget } = useTheme();

  return (
    <Pressable
      onPress={granted ? undefined : onRequest}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.lg,
        minHeight: tapTarget,
        paddingVertical: spacing.md,
        borderBottomWidth: 1,
        borderBottomColor: palette.border,
      }}
    >
      <Icon name={icon} size={26} color={granted ? palette.accent : palette.textMuted} />
      <View style={{ flex: 1 }}>
        <Text variant="bodyStrong">{title}</Text>
        <Text variant="caption" color="muted">
          {description}
        </Text>
      </View>
      <Icon
        name={granted ? 'check' : 'chevronRight'}
        size={22}
        color={granted ? palette.success : palette.textFaint}
      />
    </Pressable>
  );
}
