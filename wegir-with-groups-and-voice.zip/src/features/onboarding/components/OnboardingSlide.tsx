import { View } from 'react-native';

import { Icon, Text, type IconName } from '@/components';
import { useTheme } from '@/theme';

interface OnboardingSlideProps {
  icon: IconName;
  title: string;
  description: string;
}

export function OnboardingSlide({ icon, title, description }: OnboardingSlideProps) {
  const { palette, spacing, radius } = useTheme();

  return (
    <View style={{ alignItems: 'center', gap: spacing.lg, paddingHorizontal: spacing.xl }}>
      <View
        style={{
          width: 96,
          height: 96,
          borderRadius: radius.xl,
          backgroundColor: palette.accentSoft,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Icon name={icon} size={44} color={palette.accent} strokeWidth={1.8} />
      </View>
      <Text variant="title" style={{ textAlign: 'center' }}>
        {title}
      </Text>
      <Text variant="body" color="muted" style={{ textAlign: 'center' }}>
        {description}
      </Text>
    </View>
  );
}
