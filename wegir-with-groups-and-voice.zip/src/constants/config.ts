import { isApiConfigured } from '@/lib/api';
import { isMapboxConfigured } from '@/lib/mapbox';

// When backends are not configured yet, the app falls back to mock services
// so the UI stays runnable end to end.
export const config = {
  useMockLocation: false,
  useMockBackend: !isApiConfigured(),
  mapAvailable: isMapboxConfigured(),
  alertDefaultTtlMinutes: 30,
  policeFuzzyRadiusMeters: 400,
  convoyStretchWarnMeters: 2000,
} as const;

export const queryKeys = {
  geocoding: (q: string) => ['geocoding', q] as const,
  directions: (id: string) => ['directions', id] as const,
  weather: (lat: number, lon: number) => ['weather', lat, lon] as const,
};
