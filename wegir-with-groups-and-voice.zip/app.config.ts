import type { ExpoConfig, ConfigContext } from 'expo/config';

const LOCATION_USAGE =
  'GCS Convois utilise votre position GPS pour la navigation et le partage de convoi.';

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: 'GCS Convois',
  slug: 'gcs-convois',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  scheme: 'gcsconvois',
  userInterfaceStyle: 'dark',
  backgroundColor: '#0a0e13',
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'com.gcsconvois.app',
    infoPlist: {
      NSLocationWhenInUseUsageDescription: LOCATION_USAGE,
      NSLocationAlwaysAndWhenInUseUsageDescription: LOCATION_USAGE,
      UIBackgroundModes: ['location', 'fetch', 'remote-notification'],
    },
  },
  android: {
    package: 'com.gcsconvois.app',
    adaptiveIcon: {
      backgroundColor: '#0a0e13',
      foregroundImage: './assets/android-icon-foreground.png',
      backgroundImage: './assets/android-icon-background.png',
      monochromeImage: './assets/android-icon-monochrome.png',
    },
    predictiveBackGestureEnabled: false,
    permissions: ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION'],
  },
  web: {
    favicon: './assets/favicon.png',
  },
  plugins: [
    'expo-router',
    'expo-font',
    ['expo-location', { locationWhenInUsePermission: LOCATION_USAGE }],
    [
      '@rnmapbox/maps',
      {
        RNMapboxMapsDownloadToken: process.env.MAPBOX_DOWNLOAD_TOKEN ?? '',
      },
    ],
  ],
  experiments: {
    typedRoutes: true,
  },
});
