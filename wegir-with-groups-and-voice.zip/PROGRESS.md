# Avancement

Suivi par phase. Cocher une sous-étape quand elle est committée.

## Phase 0 — Fondations

- [x] Migration vers Expo Router, entrée `expo-router/entry`
- [x] TypeScript strict, ESLint (flat) + Prettier
- [x] Theme centralisé (couleurs dark+light, typo, espacements, rayons, ombres, `useTheme`)
- [x] Couleurs membres convoi et états
- [x] Système d'icônes SVG fait main (`src/components/icons`)
- [x] Primitives UI partagées (Text, Button, Card, Badge, Avatar, Screen, EmptyState, LoadingState)
- [x] Init clients externes derrière `lib/` (API, Mapbox, QueryClient)
- [x] Services natifs stubés derrière interfaces (géoloc: mock + expo, audio: mock)
- [x] Squelette de routes (onboarding, auth, main + tabs)
- [x] `.env.example` documenté
- [ ] Tests Jest (ajoutés en Phase 1, avec la première logique métier)

## Phase 1 — MVP navigation solo

- [ ] Carte Mapbox + position temps réel
- [ ] Recherche destination (geocoding) + favoris + récents
- [ ] Calcul d'itinéraire (Mapbox Directions) + alternatives
- [ ] HUD (vitesse, limite, ETA, distance restante) + recentrage
- [ ] Recalcul auto, mode jour/nuit

## Phase 2 — Convoi de base

- [ ] Auth API (JWT), créer/rejoindre par code
- [ ] Positions live multi-membres (Socket.IO), mini-barre convoi
- [ ] Itinéraire unifié, ETA de groupe

## Phase 3 — Alertes

- [ ] Catalogue complet, marqueurs, flux à l'approche
- [ ] Cycle de vie confirmation/infirmation/expiration, notifs

## Phase 4 — Features signature

- [ ] Accordéon anti-séparation, regroupement auto
- [ ] SOS convoi, manœuvres annoncées, coordination carburant

## Phase 5 — Push-to-talk

- [ ] Intégration LiveKit derrière `audio.service`

## Phase 6 — Polish & social

- [ ] Replay partageable, points/contributions, partage ETA
- [ ] Réglages itinéraire avancés, hors-ligne, animations
