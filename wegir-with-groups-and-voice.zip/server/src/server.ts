import { createServer } from 'node:http';

import { createApp } from './app';
import { env } from './config/env';
import { prisma } from './lib/prisma';
import { initSocket } from './realtime/socket';

const app = createApp();
const httpServer = createServer(app);
initSocket(httpServer);

httpServer.listen(env.PORT, () => {
  console.log(`GCS Convois API + WebSocket sur http://localhost:${env.PORT}`);
});

async function shutdown(): Promise<void> {
  await prisma.$disconnect();
  httpServer.close(() => process.exit(0));
}

process.on('SIGINT', () => void shutdown());
process.on('SIGTERM', () => void shutdown());
