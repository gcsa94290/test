import { Router } from 'express';

import alertRoutes from './alert.routes';
import authRoutes from './auth.routes';
import convoyRoutes from './convoy.routes';
import uploadRoutes from './upload.routes';
import userRoutes from './user.routes';

const router = Router();

router.get('/health', (_req, res) => {
  res.json({ status: 'ok' });
});

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/convoys', convoyRoutes);
router.use('/alerts', alertRoutes);
router.use('/uploads', uploadRoutes);

export default router;
