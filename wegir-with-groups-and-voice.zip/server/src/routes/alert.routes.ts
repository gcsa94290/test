import { Router } from 'express';

import * as alert from '../controllers/alert.controller';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();

router.use(authenticate);
router.post('/', alert.create);
router.get('/nearby', alert.listNearby);
router.get('/convoy/:id', alert.listForConvoy);
router.post('/:id/vote', alert.vote);

export default router;
