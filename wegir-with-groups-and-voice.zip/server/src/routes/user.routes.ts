import { Router } from 'express';

import * as user from '../controllers/user.controller';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();

router.use(authenticate);
router.get('/me', user.getMe);
router.patch('/me', user.updateMe);
router.get('/me/places', user.listPlaces);
router.post('/me/places', user.addPlace);
router.delete('/me/places/:id', user.deletePlace);
router.post('/me/device', user.registerDevice);

export default router;
