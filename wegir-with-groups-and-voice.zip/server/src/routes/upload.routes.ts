import { Router } from 'express';

import * as upload from '../controllers/upload.controller';
import { authenticate } from '../middleware/auth.middleware';
import { uploadSingleImage } from '../middleware/upload.middleware';

const router = Router();

router.post('/', authenticate, uploadSingleImage, upload.uploadImage);

export default router;
