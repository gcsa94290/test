import { Router } from 'express';

import * as convoy from '../controllers/convoy.controller';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();

router.use(authenticate);
router.post('/', convoy.create);
router.get('/', convoy.listMine);
router.post('/join', convoy.join);
router.get('/:id', convoy.getOne);
router.post('/:id/position', convoy.updatePosition);
router.patch('/:id/members/:userId/role', convoy.setRole);
router.delete('/:id/leave', convoy.leave);

export default router;
