import { Router } from 'express';

import * as auth from '../controllers/auth.controller';

const router = Router();

router.post('/otp/request', auth.requestOtp);
router.post('/otp/verify', auth.verifyOtp);
router.post('/refresh', auth.refresh);
router.post('/logout', auth.logout);

export default router;
