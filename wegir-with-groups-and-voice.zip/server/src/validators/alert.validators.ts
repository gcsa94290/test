import { z } from 'zod';

export const alertTypeSchema = z.enum([
  'ACCIDENT',
  'TRAFFIC',
  'ROADWORK',
  'ROAD_CLOSED',
  'DETOUR',
  'HAZARD',
  'STOPPED_VEHICLE',
  'POTHOLE',
  'SLIPPERY',
  'FLOOD',
  'FOG',
  'POLICE',
  'BROKEN_LIGHT',
  'PROTEST',
]);

export const createAlertSchema = z.object({
  type: alertTypeSchema,
  lat: z.number(),
  lng: z.number(),
  note: z.string().max(280).optional(),
  photoUrl: z.string().url().optional(),
  convoyId: z.string().optional(),
});

export const voteSchema = z.object({
  kind: z.enum(['CONFIRM', 'DENY']),
});

export const nearbyQuerySchema = z.object({
  lat: z.coerce.number(),
  lng: z.coerce.number(),
  radiusMeters: z.coerce.number().positive().max(50_000).default(5_000),
});

export type CreateAlertInput = z.infer<typeof createAlertSchema>;
export type VoteInput = z.infer<typeof voteSchema>;
export type NearbyQuery = z.infer<typeof nearbyQuerySchema>;
