import { z } from 'zod';

export const requestOtpSchema = z.object({
  phone: z.string().min(6).max(20),
});

export const verifyOtpSchema = z.object({
  phone: z.string().min(6).max(20),
  code: z.string().length(6),
  displayName: z.string().min(2).max(40).optional(),
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(1),
});

export type RequestOtpInput = z.infer<typeof requestOtpSchema>;
export type VerifyOtpInput = z.infer<typeof verifyOtpSchema>;
export type RefreshInput = z.infer<typeof refreshSchema>;
