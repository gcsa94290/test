import { z } from 'zod';

export const updateProfileSchema = z.object({
  displayName: z.string().min(2).max(40).optional(),
  color: z
    .string()
    .regex(/^#[0-9a-fA-F]{6}$/, 'Couleur hex invalide')
    .optional(),
});

export const savedPlaceSchema = z.object({
  kind: z.enum(['HOME', 'WORK', 'CUSTOM', 'RECENT']).default('CUSTOM'),
  label: z.string().min(1).max(40),
  address: z.string().min(1),
  lat: z.number(),
  lng: z.number(),
});

export const deviceSchema = z.object({
  expoPushToken: z.string().min(1),
  platform: z.enum(['IOS', 'ANDROID']),
  appVersion: z.string().optional(),
});

export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type SavedPlaceInput = z.infer<typeof savedPlaceSchema>;
export type DeviceInput = z.infer<typeof deviceSchema>;
