import { z } from 'zod';

export const createConvoySchema = z.object({
  name: z.string().min(1).max(60),
  destinationName: z.string().max(120).optional(),
  destinationLat: z.number().optional(),
  destinationLng: z.number().optional(),
});

export const joinConvoySchema = z.object({
  code: z.string().min(4).max(12),
});

export const updatePositionSchema = z.object({
  lat: z.number(),
  lng: z.number(),
  heading: z.number().nullable().optional(),
  speed: z.number().nullable().optional(),
  batteryLevel: z.number().int().min(0).max(100).nullable().optional(),
  fuelLevel: z.number().int().min(0).max(100).nullable().optional(),
});

export const memberRoleSchema = z.object({
  role: z.enum(['LEADER', 'SWEEP', 'MEMBER']),
});

export const socketPositionSchema = updatePositionSchema.extend({
  convoyId: z.string().min(1),
});

export type SocketPositionInput = z.infer<typeof socketPositionSchema>;
export type CreateConvoyInput = z.infer<typeof createConvoySchema>;
export type JoinConvoyInput = z.infer<typeof joinConvoySchema>;
export type UpdatePositionInput = z.infer<typeof updatePositionSchema>;
export type MemberRoleInput = z.infer<typeof memberRoleSchema>;
