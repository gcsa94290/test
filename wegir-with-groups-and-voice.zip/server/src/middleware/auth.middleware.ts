import type { NextFunction, Request, Response } from 'express';

import { unauthorized } from '../utils/httpError';
import { verifyAccessToken } from '../utils/jwt';

export function authenticate(req: Request, _res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    next(unauthorized('Token d\'acces manquant'));
    return;
  }

  const token = header.slice('Bearer '.length).trim();
  const payload = verifyAccessToken(token);
  req.user = { id: payload.sub, phone: payload.phone };
  next();
}

export function requireUser(req: Request): { id: string; phone: string } {
  if (!req.user) {
    throw unauthorized();
  }
  return req.user;
}
