import multer from 'multer';

const MAX_FILE_BYTES = 5 * 1024 * 1024;

export const uploadSingleImage = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_BYTES },
}).single('image');
