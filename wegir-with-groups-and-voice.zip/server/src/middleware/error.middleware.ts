import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';

import { Prisma } from '../generated/prisma';
import { AppError } from '../utils/httpError';

interface ErrorBody {
  message: string;
  details?: unknown;
}

export function errorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction,
): void {
  if (err instanceof AppError) {
    const body: ErrorBody = { message: err.message, details: err.details };
    res.status(err.status).json(body);
    return;
  }

  if (err instanceof ZodError) {
    res.status(400).json({ message: 'Donnees invalides', details: err.flatten() });
    return;
  }

  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    if (err.code === 'P2002') {
      res.status(409).json({ message: 'Ressource deja existante' });
      return;
    }
    if (err.code === 'P2025') {
      res.status(404).json({ message: 'Ressource introuvable' });
      return;
    }
  }

  const message = err instanceof Error ? err.message : 'Erreur serveur';
  console.error(err);
  res.status(500).json({ message: 'Erreur interne du serveur', details: message });
}
