import type { NextFunction, Request, Response } from 'express';
import type { ZodTypeAny } from 'zod';

import { badRequest } from '../utils/httpError';

type Source = 'body' | 'query' | 'params';

export function validate(schema: ZodTypeAny, source: Source = 'body') {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      next(badRequest('Donnees invalides', result.error.flatten()));
      return;
    }
    next();
  };
}
