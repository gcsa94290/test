import { isProd } from '../config/env';

export interface SmsService {
  sendOtp(phone: string, code: string): Promise<void>;
}

// Dev stub: logs the code instead of sending a paid SMS.
// Swap for Twilio / Vonage / a French provider in production.
class ConsoleSmsService implements SmsService {
  sendOtp(phone: string, code: string): Promise<void> {
    console.log(`[sms] OTP for ${phone}: ${code}`);
    return Promise.resolve();
  }
}

class ProductionSmsService implements SmsService {
  sendOtp(phone: string, _code: string): Promise<void> {
    return Promise.reject(new Error(`SMS provider not configured (cannot send OTP to ${phone})`));
  }
}

export const smsService: SmsService = isProd
  ? new ProductionSmsService()
  : new ConsoleSmsService();
