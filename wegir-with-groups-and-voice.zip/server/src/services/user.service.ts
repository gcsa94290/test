import type { SavedPlace } from '../generated/prisma';
import { prisma } from '../lib/prisma';
import { toSelfUser, type SelfUser } from '../types/user.types';
import { notFound } from '../utils/httpError';
import type {
  DeviceInput,
  SavedPlaceInput,
  UpdateProfileInput,
} from '../validators/user.validators';

export async function getProfile(userId: string): Promise<SelfUser> {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    throw notFound('Utilisateur introuvable');
  }
  return toSelfUser(user);
}

export async function updateProfile(
  userId: string,
  input: UpdateProfileInput,
): Promise<SelfUser> {
  const user = await prisma.user.update({ where: { id: userId }, data: input });
  return toSelfUser(user);
}

export function listPlaces(userId: string): Promise<SavedPlace[]> {
  return prisma.savedPlace.findMany({
    where: { userId },
    orderBy: [{ kind: 'asc' }, { lastUsedAt: 'desc' }],
  });
}

export function addPlace(userId: string, input: SavedPlaceInput): Promise<SavedPlace> {
  return prisma.savedPlace.create({ data: { userId, ...input } });
}

export async function deletePlace(userId: string, placeId: string): Promise<void> {
  await prisma.savedPlace.deleteMany({ where: { id: placeId, userId } });
}

export async function registerDevice(userId: string, input: DeviceInput): Promise<void> {
  await prisma.device.upsert({
    where: { expoPushToken: input.expoPushToken },
    create: {
      userId,
      expoPushToken: input.expoPushToken,
      platform: input.platform,
      appVersion: input.appVersion ?? null,
    },
    update: {
      userId,
      platform: input.platform,
      appVersion: input.appVersion ?? null,
      lastActiveAt: new Date(),
    },
  });
}
