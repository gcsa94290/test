import { isCloudinaryConfigured, uploadBuffer } from '../lib/cloudinary';
import { AppError } from '../utils/httpError';

export interface UploadResult {
  url: string;
  publicId: string;
}

export async function uploadImage(buffer: Buffer, folder: string): Promise<UploadResult> {
  if (!isCloudinaryConfigured()) {
    throw new AppError(503, 'Cloudinary non configure');
  }
  const result = await uploadBuffer(buffer, `gcs-convois/${folder}`);
  return { url: result.secure_url, publicId: result.public_id };
}
