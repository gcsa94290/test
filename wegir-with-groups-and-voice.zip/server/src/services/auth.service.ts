import crypto from 'node:crypto';

import { env } from '../config/env';
import { prisma } from '../lib/prisma';
import type { AuthTokens } from '../types/auth.types';
import { toSelfUser, type SelfUser } from '../types/user.types';
import { badRequest, unauthorized } from '../utils/httpError';
import { signAccessToken, signRefreshToken, verifyRefreshToken } from '../utils/jwt';
import { generateOtp, hashOtp } from '../utils/otp';
import { hashPhone, normalizePhone } from '../utils/phone';
import type { RequestOtpInput, VerifyOtpInput } from '../validators/auth.validators';

import { smsService } from './sms.service';

export interface AuthResult {
  user: SelfUser;
  tokens: AuthTokens;
}

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

async function issueTokens(userId: string, phone: string): Promise<AuthTokens> {
  const payload = { sub: userId, phone };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);
  await prisma.refreshToken.create({
    data: {
      userId,
      tokenHash: hashToken(refreshToken),
      expiresAt: new Date(Date.now() + env.JWT_REFRESH_TTL_SECONDS * 1000),
    },
  });
  return { accessToken, refreshToken };
}

export async function requestOtp(input: RequestOtpInput): Promise<void> {
  const phone = normalizePhone(input.phone);
  const code = generateOtp();
  await prisma.phoneVerification.create({
    data: {
      phone,
      codeHash: hashOtp(code),
      purpose: 'LOGIN',
      expiresAt: new Date(Date.now() + env.OTP_TTL_SECONDS * 1000),
    },
  });
  await smsService.sendOtp(phone, code);
}

export async function verifyOtp(input: VerifyOtpInput): Promise<AuthResult> {
  const phone = normalizePhone(input.phone);
  const verification = await prisma.phoneVerification.findFirst({
    where: { phone, consumedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  });
  if (!verification) {
    throw badRequest('Code expire ou introuvable');
  }
  if (verification.attempts >= env.OTP_MAX_ATTEMPTS) {
    throw badRequest('Trop de tentatives, demandez un nouveau code');
  }
  if (verification.codeHash !== hashOtp(input.code)) {
    await prisma.phoneVerification.update({
      where: { id: verification.id },
      data: { attempts: { increment: 1 } },
    });
    throw unauthorized('Code invalide');
  }

  await prisma.phoneVerification.update({
    where: { id: verification.id },
    data: { consumedAt: new Date() },
  });

  const user = await prisma.user.upsert({
    where: { phone },
    update: { phoneVerifiedAt: new Date(), lastSeenAt: new Date() },
    create: {
      phone,
      phoneHash: hashPhone(phone),
      displayName: input.displayName ?? 'Pilote',
      phoneVerifiedAt: new Date(),
      settings: { create: {} },
      routePreference: { create: {} },
    },
  });

  return { user: toSelfUser(user), tokens: await issueTokens(user.id, user.phone) };
}

export async function refresh(refreshToken: string): Promise<AuthTokens> {
  const payload = verifyRefreshToken(refreshToken);
  const stored = await prisma.refreshToken.findUnique({
    where: { tokenHash: hashToken(refreshToken) },
  });
  if (!stored || stored.expiresAt < new Date()) {
    throw unauthorized('Session expiree');
  }
  await prisma.refreshToken.delete({ where: { id: stored.id } });
  return issueTokens(payload.sub, payload.phone);
}

export async function logout(refreshToken: string): Promise<void> {
  await prisma.refreshToken.deleteMany({ where: { tokenHash: hashToken(refreshToken) } });
}
