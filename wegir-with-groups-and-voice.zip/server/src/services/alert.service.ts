import {
  ALERT_TTL_MINUTES,
  CONTRIBUTION_POINTS_PER_REPORT,
  POLICE_FUZZY_RADIUS_METERS,
} from '../config/constants';
import type { Alert } from '../generated/prisma';
import { prisma } from '../lib/prisma';
import { distanceMeters, fuzzPoint } from '../utils/geo';
import { notFound } from '../utils/httpError';
import type { CreateAlertInput, NearbyQuery, VoteInput } from '../validators/alert.validators';

const DENY_THRESHOLD = 3;

export async function createAlert(authorId: string, input: CreateAlertInput): Promise<Alert> {
  const isPolice = input.type === 'POLICE';
  const point = isPolice
    ? fuzzPoint({ lat: input.lat, lng: input.lng }, POLICE_FUZZY_RADIUS_METERS)
    : { lat: input.lat, lng: input.lng };
  const expiresAt = new Date(Date.now() + ALERT_TTL_MINUTES * 60 * 1000);

  const [alert] = await prisma.$transaction([
    prisma.alert.create({
      data: {
        type: input.type,
        lat: point.lat,
        lng: point.lng,
        fuzzyRadiusMeters: isPolice ? POLICE_FUZZY_RADIUS_METERS : 0,
        note: input.note ?? null,
        photoUrl: input.photoUrl ?? null,
        authorId,
        convoyId: input.convoyId ?? null,
        expiresAt,
      },
    }),
    prisma.user.update({
      where: { id: authorId },
      data: { contributionPoints: { increment: CONTRIBUTION_POINTS_PER_REPORT } },
    }),
  ]);
  return alert;
}

export async function listNearby(query: NearbyQuery): Promise<Alert[]> {
  const active = await prisma.alert.findMany({ where: { expiresAt: { gt: new Date() } } });
  return active.filter(
    (alert) =>
      distanceMeters({ lat: query.lat, lng: query.lng }, { lat: alert.lat, lng: alert.lng }) <=
      query.radiusMeters,
  );
}

export function listForConvoy(convoyId: string): Promise<Alert[]> {
  return prisma.alert.findMany({
    where: { convoyId, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  });
}

export async function voteAlert(
  alertId: string,
  voterId: string,
  input: VoteInput,
): Promise<Alert> {
  const alert = await prisma.alert.findUnique({ where: { id: alertId } });
  if (!alert) {
    throw notFound('Alerte introuvable');
  }
  await prisma.alertVote.upsert({
    where: { alertId_voterId: { alertId, voterId } },
    create: { alertId, voterId, kind: input.kind },
    update: { kind: input.kind },
  });
  const [confirmations, denials] = await Promise.all([
    prisma.alertVote.count({ where: { alertId, kind: 'CONFIRM' } }),
    prisma.alertVote.count({ where: { alertId, kind: 'DENY' } }),
  ]);
  const shouldExpire = denials >= DENY_THRESHOLD && denials > confirmations;
  return prisma.alert.update({
    where: { id: alertId },
    data: {
      confirmations,
      denials,
      ...(shouldExpire ? { expiresAt: new Date() } : {}),
    },
  });
}
