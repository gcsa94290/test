import { Prisma } from '../generated/prisma';
import { prisma } from '../lib/prisma';
import { toConvoyDto, type ConvoyDto } from '../types/convoy.types';
import { convoyCode } from '../utils/code';
import { forbidden, notFound } from '../utils/httpError';
import type {
  CreateConvoyInput,
  JoinConvoyInput,
  MemberRoleInput,
  UpdatePositionInput,
} from '../validators/convoy.validators';

const memberInclude = {
  members: { include: { user: { select: { displayName: true, color: true } } } },
} satisfies Prisma.ConvoyInclude;

async function loadConvoy(convoyId: string): Promise<ConvoyDto> {
  const convoy = await prisma.convoy.findUnique({
    where: { id: convoyId },
    include: memberInclude,
  });
  if (!convoy) {
    throw notFound('Convoi introuvable');
  }
  return toConvoyDto(convoy);
}

export async function createConvoy(userId: string, input: CreateConvoyInput): Promise<ConvoyDto> {
  const convoy = await prisma.convoy.create({
    data: {
      code: convoyCode(),
      name: input.name,
      destinationName: input.destinationName ?? null,
      destinationLat: input.destinationLat ?? null,
      destinationLng: input.destinationLng ?? null,
      leaderId: userId,
      members: { create: { userId, role: 'LEADER', presence: 'LIVE' } },
    },
    include: memberInclude,
  });
  return toConvoyDto(convoy);
}

export async function joinConvoy(userId: string, input: JoinConvoyInput): Promise<ConvoyDto> {
  const convoy = await prisma.convoy.findUnique({ where: { code: input.code.toUpperCase() } });
  if (!convoy || convoy.status === 'ENDED') {
    throw notFound('Convoi introuvable ou termine');
  }
  await prisma.convoyMember.upsert({
    where: { convoyId_userId: { convoyId: convoy.id, userId } },
    create: { convoyId: convoy.id, userId, role: 'MEMBER', presence: 'LIVE' },
    update: { presence: 'LIVE' },
  });
  return loadConvoy(convoy.id);
}

export function getConvoy(convoyId: string): Promise<ConvoyDto> {
  return loadConvoy(convoyId);
}

export async function ensureMembership(convoyId: string, userId: string): Promise<void> {
  const member = await prisma.convoyMember.findUnique({
    where: { convoyId_userId: { convoyId, userId } },
  });
  if (!member) {
    throw forbidden('Vous n\'etes pas membre de ce convoi');
  }
}

export async function updatePosition(
  convoyId: string,
  userId: string,
  input: UpdatePositionInput,
): Promise<ConvoyDto> {
  await ensureMembership(convoyId, userId);
  await prisma.convoyMember.update({
    where: { convoyId_userId: { convoyId, userId } },
    data: {
      lastLat: input.lat,
      lastLng: input.lng,
      lastHeading: input.heading ?? null,
      lastSpeed: input.speed ?? null,
      batteryLevel: input.batteryLevel ?? null,
      fuelLevel: input.fuelLevel ?? null,
      presence: 'LIVE',
    },
  });
  return loadConvoy(convoyId);
}

export async function leaveConvoy(convoyId: string, userId: string): Promise<void> {
  await prisma.convoyMember.deleteMany({ where: { convoyId, userId } });
}

export async function setMemberRole(
  convoyId: string,
  requesterId: string,
  targetUserId: string,
  input: MemberRoleInput,
): Promise<ConvoyDto> {
  const convoy = await prisma.convoy.findUnique({ where: { id: convoyId } });
  if (!convoy) {
    throw notFound('Convoi introuvable');
  }
  if (convoy.leaderId !== requesterId) {
    throw forbidden('Seul le leader peut changer les roles');
  }
  await prisma.convoyMember.update({
    where: { convoyId_userId: { convoyId, userId: targetUserId } },
    data: { role: input.role },
  });
  return loadConvoy(convoyId);
}

export function listMyConvoys(userId: string): Promise<ConvoyDto[]> {
  return prisma.convoy
    .findMany({
      where: { members: { some: { userId } }, status: 'ACTIVE' },
      include: memberInclude,
    })
    .then((convoys) => convoys.map(toConvoyDto));
}
