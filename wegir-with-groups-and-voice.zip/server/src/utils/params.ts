import type { Request } from 'express';

import { badRequest } from './httpError';

export function requireParam(req: Request, name: string): string {
  const value = req.params[name];
  if (!value) {
    throw badRequest(`Parametre manquant: ${name}`);
  }
  return value;
}
