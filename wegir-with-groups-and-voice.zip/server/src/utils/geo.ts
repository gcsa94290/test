export interface Point {
  lat: number;
  lng: number;
}

const EARTH_RADIUS_M = 6_371_000;
const toRad = (deg: number): number => (deg * Math.PI) / 180;

export function distanceMeters(a: Point, b: Point): number {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * EARTH_RADIUS_M * Math.asin(Math.sqrt(h));
}

// Offsets a point by a random vector inside the given radius.
// Used to publish police reports as a fuzzy zone rather than an exact spot.
export function fuzzPoint(point: Point, radiusMeters: number): Point {
  const distance = Math.sqrt(Math.random()) * radiusMeters;
  const angle = Math.random() * 2 * Math.PI;
  const dLat = (distance * Math.cos(angle)) / EARTH_RADIUS_M;
  const dLng =
    (distance * Math.sin(angle)) / (EARTH_RADIUS_M * Math.cos(toRad(point.lat)));
  return {
    lat: point.lat + (dLat * 180) / Math.PI,
    lng: point.lng + (dLng * 180) / Math.PI,
  };
}
