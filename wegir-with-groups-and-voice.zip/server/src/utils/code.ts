const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function convoyCode(length = 6): string {
  let code = '';
  for (let i = 0; i < length; i += 1) {
    code += ALPHABET.charAt(Math.floor(Math.random() * ALPHABET.length));
  }
  return code;
}
