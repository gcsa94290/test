import jwt from 'jsonwebtoken';
import { z } from 'zod';

import { env } from '../config/env';
import type { TokenPayload } from '../types/auth.types';

import { unauthorized } from './httpError';

const payloadSchema = z.object({
  sub: z.string(),
  phone: z.string(),
});

export function signAccessToken(payload: TokenPayload): string {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, { expiresIn: env.JWT_ACCESS_TTL_SECONDS });
}

export function signRefreshToken(payload: TokenPayload): string {
  return jwt.sign(payload, env.JWT_REFRESH_SECRET, { expiresIn: env.JWT_REFRESH_TTL_SECONDS });
}

function verifyToken(token: string, secret: string): TokenPayload {
  try {
    const decoded: unknown = jwt.verify(token, secret);
    return payloadSchema.parse(decoded);
  } catch {
    throw unauthorized('Token invalide ou expire');
  }
}

export const verifyAccessToken = (token: string): TokenPayload =>
  verifyToken(token, env.JWT_ACCESS_SECRET);

export const verifyRefreshToken = (token: string): TokenPayload =>
  verifyToken(token, env.JWT_REFRESH_SECRET);
