export class AppError extends Error {
  readonly status: number;
  readonly details?: unknown;

  constructor(status: number, message: string, details?: unknown) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.details = details;
  }
}

export const badRequest = (message: string, details?: unknown): AppError =>
  new AppError(400, message, details);
export const unauthorized = (message = 'Non autorise'): AppError => new AppError(401, message);
export const forbidden = (message = 'Interdit'): AppError => new AppError(403, message);
export const notFound = (message = 'Introuvable'): AppError => new AppError(404, message);
export const conflict = (message: string): AppError => new AppError(409, message);
