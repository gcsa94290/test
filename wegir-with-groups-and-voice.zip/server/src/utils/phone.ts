import crypto from 'node:crypto';

import { env } from '../config/env';

// Light E.164 normalization. A real deployment should use libphonenumber.
export function normalizePhone(raw: string): string {
  const trimmed = raw.replace(/[\s().-]/g, '');
  if (trimmed.startsWith('00')) {
    return `+${trimmed.slice(2)}`;
  }
  return trimmed;
}

export function hashPhone(phone: string): string {
  return crypto.createHmac('sha256', env.PHONE_HASH_PEPPER).update(phone).digest('hex');
}
