import type { Server } from 'socket.io';

import { convoyRoom } from './events';

let io: Server | null = null;

export function setIo(server: Server): void {
  io = server;
}

export function emitToConvoy(convoyId: string, event: string, payload: unknown): void {
  io?.to(convoyRoom(convoyId)).emit(event, payload);
}
