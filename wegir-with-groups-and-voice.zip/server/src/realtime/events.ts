export const SocketEvents = {
  JOIN_CONVOY: 'convoy:join',
  LEAVE_CONVOY: 'convoy:leave',
  POSITION_UPDATE: 'position:update',
  CONVOY_UPDATE: 'convoy:update',
  ALERT_NEW: 'alert:new',
  SOS: 'sos',
  MANEUVER: 'maneuver',
  // Voice channel (Push-to-Talk)
  VOICE_START: 'voice:start',
  VOICE_STOP: 'voice:stop',
  VOICE_SIGNAL: 'voice:signal',   // WebRTC signaling (offer/answer/ice)
  VOICE_SPEAKERS: 'voice:speakers', // broadcast current speakers list
} as const;

export function convoyRoom(convoyId: string): string {
  return `convoy:${convoyId}`;
}

export function voiceRoom(convoyId: string): string {
  return `voice:${convoyId}`;
}
