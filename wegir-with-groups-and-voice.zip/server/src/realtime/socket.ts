import type { Server as HttpServer } from 'node:http';

import { Server, type Socket } from 'socket.io';

import { env } from '../config/env';
import { ensureMembership, updatePosition } from '../services/convoy.service';
import { verifyAccessToken } from '../utils/jwt';
import { socketPositionSchema } from '../validators/convoy.validators';

import { SocketEvents, convoyRoom, voiceRoom } from './events';
import { setIo } from './io';

interface SocketData {
  userId: string;
}

function userIdOf(socket: Socket): string {
  return (socket.data as SocketData).userId;
}

// Track who is currently speaking per convoy: convoyId -> Set<userId>
const activeSpeakers = new Map<string, Set<string>>();

function getSpeakers(convoyId: string): string[] {
  return [...(activeSpeakers.get(convoyId) ?? [])];
}

export function initSocket(httpServer: HttpServer): Server {
  const io = new Server(httpServer, {
    cors: { origin: env.CORS_ORIGIN },
  });

  io.use((socket, next) => {
    const rawToken: unknown = socket.handshake.auth?.token;
    const token = typeof rawToken === 'string' ? rawToken : '';
    try {
      const payload = verifyAccessToken(token);
      (socket.data as SocketData).userId = payload.sub;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    // ── Convoy room ──────────────────────────────────────────────────────────
    socket.on(SocketEvents.JOIN_CONVOY, (convoyId: unknown) => {
      if (typeof convoyId !== 'string') return;
      void ensureMembership(convoyId, userIdOf(socket))
        .then(() => {
          void socket.join(convoyRoom(convoyId));
          void socket.join(voiceRoom(convoyId));
          // Send current speakers list to joining user
          socket.emit(SocketEvents.VOICE_SPEAKERS, {
            convoyId,
            speakers: getSpeakers(convoyId),
          });
        })
        .catch(() => socket.emit('error', 'join refused'));
    });

    socket.on(SocketEvents.LEAVE_CONVOY, (convoyId: unknown) => {
      if (typeof convoyId !== 'string') return;
      // Clean up speaking state
      const speakers = activeSpeakers.get(convoyId);
      if (speakers) {
        const userId = userIdOf(socket);
        if (speakers.has(userId)) {
          speakers.delete(userId);
          io.to(voiceRoom(convoyId)).emit(SocketEvents.VOICE_SPEAKERS, {
            convoyId,
            speakers: getSpeakers(convoyId),
          });
        }
      }
      void socket.leave(convoyRoom(convoyId));
      void socket.leave(voiceRoom(convoyId));
    });

    // ── Position ─────────────────────────────────────────────────────────────
    socket.on(SocketEvents.POSITION_UPDATE, (payload: unknown) => {
      const parsed = socketPositionSchema.safeParse(payload);
      if (!parsed.success) return;
      const { convoyId, ...position } = parsed.data;
      void updatePosition(convoyId, userIdOf(socket), position)
        .then((convoy) => io.to(convoyRoom(convoyId)).emit(SocketEvents.CONVOY_UPDATE, convoy))
        .catch(() => socket.emit('error', 'position rejected'));
    });

    // ── Push-to-talk ──────────────────────────────────────────────────────────
    socket.on(SocketEvents.VOICE_START, (payload: unknown) => {
      if (typeof payload !== 'object' || payload === null) return;
      const { convoyId } = payload as Record<string, unknown>;
      if (typeof convoyId !== 'string') return;

      const userId = userIdOf(socket);
      if (!activeSpeakers.has(convoyId)) activeSpeakers.set(convoyId, new Set());
      activeSpeakers.get(convoyId)!.add(userId);

      io.to(voiceRoom(convoyId)).emit(SocketEvents.VOICE_SPEAKERS, {
        convoyId,
        speakers: getSpeakers(convoyId),
      });
    });

    socket.on(SocketEvents.VOICE_STOP, (payload: unknown) => {
      if (typeof payload !== 'object' || payload === null) return;
      const { convoyId } = payload as Record<string, unknown>;
      if (typeof convoyId !== 'string') return;

      const userId = userIdOf(socket);
      activeSpeakers.get(convoyId)?.delete(userId);

      io.to(voiceRoom(convoyId)).emit(SocketEvents.VOICE_SPEAKERS, {
        convoyId,
        speakers: getSpeakers(convoyId),
      });
    });

    // ── WebRTC signaling (offer / answer / ICE candidates) ────────────────────
    // Relay signal to all other members in the voice room
    socket.on(SocketEvents.VOICE_SIGNAL, (payload: unknown) => {
      if (typeof payload !== 'object' || payload === null) return;
      const { convoyId, ...signal } = payload as Record<string, unknown>;
      if (typeof convoyId !== 'string') return;

      // Broadcast to everyone in the voice room *except* the sender
      socket.to(voiceRoom(convoyId)).emit(SocketEvents.VOICE_SIGNAL, {
        fromUserId: userIdOf(socket),
        ...signal,
      });
    });

    // ── Cleanup on disconnect ─────────────────────────────────────────────────
    socket.on('disconnect', () => {
      const userId = userIdOf(socket);
      for (const [convoyId, speakers] of activeSpeakers.entries()) {
        if (speakers.has(userId)) {
          speakers.delete(userId);
          io.to(voiceRoom(convoyId)).emit(SocketEvents.VOICE_SPEAKERS, {
            convoyId,
            speakers: getSpeakers(convoyId),
          });
        }
      }
    });
  });

  setIo(io);
  return io;
}
