export interface AuthUser {
  id: string;
  phone: string;
}

export interface TokenPayload {
  sub: string;
  phone: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}
