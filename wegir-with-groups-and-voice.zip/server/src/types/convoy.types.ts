import type { Convoy, ConvoyMember, MemberPresence, MemberRole, User } from '../generated/prisma';

export interface MemberDto {
  id: string;
  userId: string;
  displayName: string;
  color: string;
  role: MemberRole;
  presence: MemberPresence;
  lat: number | null;
  lng: number | null;
  heading: number | null;
  speed: number | null;
  batteryLevel: number | null;
  fuelLevel: number | null;
}

export interface ConvoyDto {
  id: string;
  code: string;
  name: string;
  destinationName: string | null;
  destinationLat: number | null;
  destinationLng: number | null;
  leaderId: string;
  status: Convoy['status'];
  members: MemberDto[];
}

type MemberWithUser = ConvoyMember & { user: Pick<User, 'displayName' | 'color'> };
type ConvoyWithMembers = Convoy & { members: MemberWithUser[] };

export function toMemberDto(member: MemberWithUser): MemberDto {
  return {
    id: member.id,
    userId: member.userId,
    displayName: member.user.displayName,
    color: member.user.color,
    role: member.role,
    presence: member.presence,
    lat: member.lastLat,
    lng: member.lastLng,
    heading: member.lastHeading,
    speed: member.lastSpeed,
    batteryLevel: member.batteryLevel,
    fuelLevel: member.fuelLevel,
  };
}

export function toConvoyDto(convoy: ConvoyWithMembers): ConvoyDto {
  return {
    id: convoy.id,
    code: convoy.code,
    name: convoy.name,
    destinationName: convoy.destinationName,
    destinationLat: convoy.destinationLat,
    destinationLng: convoy.destinationLng,
    leaderId: convoy.leaderId,
    status: convoy.status,
    members: convoy.members.map(toMemberDto),
  };
}
