import type { User } from '../generated/prisma';

export interface PublicUser {
  id: string;
  displayName: string;
  avatarUrl: string | null;
  color: string;
  level: number;
  contributionPoints: number;
}

export interface SelfUser extends PublicUser {
  phone: string;
  recoveryEmail: string | null;
  reportsCount: number;
  confirmedReportsCount: number;
  convoysCompleted: number;
  createdAt: string;
}

export function toPublicUser(user: User): PublicUser {
  return {
    id: user.id,
    displayName: user.displayName,
    avatarUrl: user.avatarUrl,
    color: user.color,
    level: user.level,
    contributionPoints: user.contributionPoints,
  };
}

export function toSelfUser(user: User): SelfUser {
  return {
    ...toPublicUser(user),
    phone: user.phone,
    recoveryEmail: user.recoveryEmail,
    reportsCount: user.reportsCount,
    confirmedReportsCount: user.confirmedReportsCount,
    convoysCompleted: user.convoysCompleted,
    createdAt: user.createdAt.toISOString(),
  };
}
