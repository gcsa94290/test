import { requireUser } from '../middleware/auth.middleware';
import * as convoyService from '../services/convoy.service';
import { SocketEvents } from '../realtime/events';
import { emitToConvoy } from '../realtime/io';
import { asyncHandler } from '../utils/asyncHandler';
import { requireParam } from '../utils/params';
import {
  createConvoySchema,
  joinConvoySchema,
  memberRoleSchema,
  updatePositionSchema,
} from '../validators/convoy.validators';

export const create = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const convoy = await convoyService.createConvoy(user.id, createConvoySchema.parse(req.body));
  res.status(201).json(convoy);
});

export const join = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const convoy = await convoyService.joinConvoy(user.id, joinConvoySchema.parse(req.body));
  emitToConvoy(convoy.id, SocketEvents.CONVOY_UPDATE, convoy);
  res.json(convoy);
});

export const listMine = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  res.json(await convoyService.listMyConvoys(user.id));
});

export const getOne = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const convoyId = requireParam(req, 'id');
  await convoyService.ensureMembership(convoyId, user.id);
  res.json(await convoyService.getConvoy(convoyId));
});

export const updatePosition = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const convoyId = requireParam(req, 'id');
  const convoy = await convoyService.updatePosition(
    convoyId,
    user.id,
    updatePositionSchema.parse(req.body),
  );
  emitToConvoy(convoyId, SocketEvents.CONVOY_UPDATE, convoy);
  res.json(convoy);
});

export const setRole = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const convoyId = requireParam(req, 'id');
  const targetUserId = requireParam(req, 'userId');
  const convoy = await convoyService.setMemberRole(
    convoyId,
    user.id,
    targetUserId,
    memberRoleSchema.parse(req.body),
  );
  emitToConvoy(convoyId, SocketEvents.CONVOY_UPDATE, convoy);
  res.json(convoy);
});

export const leave = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const convoyId = requireParam(req, 'id');
  await convoyService.leaveConvoy(convoyId, user.id);
  res.status(204).send();
});
