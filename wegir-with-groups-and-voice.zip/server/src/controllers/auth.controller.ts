import * as authService from '../services/auth.service';
import { asyncHandler } from '../utils/asyncHandler';
import { refreshSchema, requestOtpSchema, verifyOtpSchema } from '../validators/auth.validators';

export const requestOtp = asyncHandler(async (req, res) => {
  await authService.requestOtp(requestOtpSchema.parse(req.body));
  res.status(202).json({ sent: true });
});

export const verifyOtp = asyncHandler(async (req, res) => {
  const result = await authService.verifyOtp(verifyOtpSchema.parse(req.body));
  res.json(result);
});

export const refresh = asyncHandler(async (req, res) => {
  const { refreshToken } = refreshSchema.parse(req.body);
  res.json(await authService.refresh(refreshToken));
});

export const logout = asyncHandler(async (req, res) => {
  const { refreshToken } = refreshSchema.parse(req.body);
  await authService.logout(refreshToken);
  res.status(204).send();
});
