import { requireUser } from '../middleware/auth.middleware';
import { SocketEvents } from '../realtime/events';
import { emitToConvoy } from '../realtime/io';
import * as alertService from '../services/alert.service';
import { asyncHandler } from '../utils/asyncHandler';
import { requireParam } from '../utils/params';
import { createAlertSchema, nearbyQuerySchema, voteSchema } from '../validators/alert.validators';

export const create = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const alert = await alertService.createAlert(user.id, createAlertSchema.parse(req.body));
  if (alert.convoyId) {
    emitToConvoy(alert.convoyId, SocketEvents.ALERT_NEW, alert);
  }
  res.status(201).json(alert);
});

export const listNearby = asyncHandler(async (req, res) => {
  res.json(await alertService.listNearby(nearbyQuerySchema.parse(req.query)));
});

export const listForConvoy = asyncHandler(async (req, res) => {
  res.json(await alertService.listForConvoy(requireParam(req, 'id')));
});

export const vote = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  const alert = await alertService.voteAlert(
    requireParam(req, 'id'),
    user.id,
    voteSchema.parse(req.body),
  );
  res.json(alert);
});
