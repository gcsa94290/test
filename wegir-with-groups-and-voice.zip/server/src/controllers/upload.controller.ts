import { z } from 'zod';

import { requireUser } from '../middleware/auth.middleware';
import * as uploadService from '../services/upload.service';
import { asyncHandler } from '../utils/asyncHandler';
import { badRequest } from '../utils/httpError';

const folderSchema = z.object({ folder: z.enum(['avatars', 'alerts']).default('avatars') });

export const uploadImage = asyncHandler(async (req, res) => {
  requireUser(req);
  const file = req.file;
  if (!file) {
    throw badRequest('Aucun fichier fourni (champ "image")');
  }
  const { folder } = folderSchema.parse(req.body);
  res.status(201).json(await uploadService.uploadImage(file.buffer, folder));
});
