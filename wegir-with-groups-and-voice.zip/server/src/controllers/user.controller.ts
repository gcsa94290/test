import { requireUser } from '../middleware/auth.middleware';
import * as userService from '../services/user.service';
import { asyncHandler } from '../utils/asyncHandler';
import { requireParam } from '../utils/params';
import { deviceSchema, savedPlaceSchema, updateProfileSchema } from '../validators/user.validators';

export const getMe = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  res.json(await userService.getProfile(user.id));
});

export const updateMe = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  res.json(await userService.updateProfile(user.id, updateProfileSchema.parse(req.body)));
});

export const listPlaces = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  res.json(await userService.listPlaces(user.id));
});

export const addPlace = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  res.status(201).json(await userService.addPlace(user.id, savedPlaceSchema.parse(req.body)));
});

export const deletePlace = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  await userService.deletePlace(user.id, requireParam(req, 'id'));
  res.status(204).send();
});

export const registerDevice = asyncHandler(async (req, res) => {
  const user = requireUser(req);
  await userService.registerDevice(user.id, deviceSchema.parse(req.body));
  res.status(204).send();
});
