# GCS Convois - API

Backend de l'application GCS Convois. Node.js + Express + Prisma (MySQL) + Socket.IO + Cloudinary, TypeScript strict (zéro `any`).

## Stack

- **Express** : API REST sous `/api`
- **Prisma** : ORM, base **MySQL** (admin via phpMyAdmin)
- **Socket.IO** : positions live du convoi (rooms par convoi)
- **Cloudinary** : upload d'images (avatars, photos d'alerte)
- **JWT** (access + refresh) avec **bcryptjs**
- **zod** : validation + dérivation des types

## Mise en route

```bash
cd server
npm install
cp .env.example .env          # renseigner DATABASE_URL, secrets JWT, Cloudinary
npm run prisma:generate
npm run prisma:migrate        # cree les tables (MySQL doit tourner)
npm run dev                   # API + WS sur http://localhost:4000
```

## Scripts

```bash
npm run dev              # tsx watch
npm run build            # tsc -> dist/
npm run start            # node dist/server.js
npm run typecheck        # tsc --noEmit
npm run lint             # eslint (no-explicit-any en erreur)
npm run prisma:studio    # explorateur de donnees
```

## Structure

```
src/
  config/        env (validé zod) + constantes
  lib/           prisma, cloudinary
  types/         interfaces et DTOs (+ augmentation Express.Request)
  middleware/    auth (JWT), validation, erreurs, 404, upload
  validators/    schemas zod (source des types d'entrée)
  services/      logique métier (auth, user, convoy, alert, upload)
  controllers/   adaptateurs HTTP (parsing + réponses)
  routes/        définition des endpoints
  realtime/      passerelle Socket.IO (events, io, socket)
  utils/         jwt, password, geo, code, httpError, asyncHandler, params
  app.ts         assemblage Express
  server.ts      bootstrap HTTP + WebSocket
prisma/
  schema.prisma  28 modèles, 27 enums (auth phone-OTP, convoi, alertes, trajets, véhicules, badges, RGPD...)
```

## Endpoints principaux

| Méthode | Route | Description |
|---------|-------|-------------|
| POST | `/api/auth/otp/request` | Envoyer un code SMS au numéro |
| POST | `/api/auth/otp/verify` | Vérifier le code, crée le compte si besoin |
| POST | `/api/auth/refresh` | Rotation du token |
| POST | `/api/auth/logout` | Révoquer la session |
| GET | `/api/users/me` | Profil courant |
| POST | `/api/users/me/places` | Favori / destination récente |
| POST | `/api/users/me/device` | Enregistrer le token push |
| POST | `/api/convoys` | Créer un convoi |
| POST | `/api/convoys/join` | Rejoindre par code |
| GET | `/api/convoys/:id` | Détail convoi |
| POST | `/api/convoys/:id/position` | Mettre à jour sa position |
| POST | `/api/alerts` | Créer un signalement |
| GET | `/api/alerts/nearby` | Alertes proches |
| POST | `/api/alerts/:id/vote` | Confirmer / infirmer |
| POST | `/api/uploads` | Upload image (Cloudinary) |

Auth = **téléphone + code SMS (OTP)**. Le numéro est l'identité (`User.phone` unique), tout le reste pointe sur `User.id`. En dev, le code OTP est loggé dans la console (pas de SMS payant).

WebSocket : connexion avec `auth.token` (JWT), events `convoy:join`, `position:update` -> diffusion `convoy:update`.

> Les contrôles police sont enregistrés dans une **zone floutée** (jamais en point exact).
