export const SocketEvents = {
  JOIN_CONVOY: 'convoy:join',
  LEAVE_CONVOY: 'convoy:leave',
  POSITION_UPDATE: 'position:update',
  CONVOY_UPDATE: 'convoy:update',
  ALERT_NEW: 'alert:new',
  SOS: 'sos',
  MANEUVER: 'maneuver',
} as const;

export function convoyRoom(convoyId: string): string {
  return `convoy:${convoyId}`;
}
