import type { Server as HttpServer } from 'node:http';

import { Server, type Socket } from 'socket.io';

import { env } from '../config/env';
import { ensureMembership, updatePosition } from '../services/convoy.service';
import { verifyAccessToken } from '../utils/jwt';
import { socketPositionSchema } from '../validators/convoy.validators';

import { SocketEvents, convoyRoom } from './events';
import { setIo } from './io';

interface SocketData {
  userId: string;
}

function userIdOf(socket: Socket): string {
  return (socket.data as SocketData).userId;
}

export function initSocket(httpServer: HttpServer): Server {
  const io = new Server(httpServer, {
    cors: { origin: env.CORS_ORIGIN },
  });

  io.use((socket, next) => {
    const rawToken: unknown = socket.handshake.auth?.token;
    const token = typeof rawToken === 'string' ? rawToken : '';
    try {
      const payload = verifyAccessToken(token);
      (socket.data as SocketData).userId = payload.sub;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    socket.on(SocketEvents.JOIN_CONVOY, (convoyId: unknown) => {
      if (typeof convoyId !== 'string') return;
      void ensureMembership(convoyId, userIdOf(socket))
        .then(() => socket.join(convoyRoom(convoyId)))
        .catch(() => socket.emit('error', 'join refused'));
    });

    socket.on(SocketEvents.LEAVE_CONVOY, (convoyId: unknown) => {
      if (typeof convoyId === 'string') {
        void socket.leave(convoyRoom(convoyId));
      }
    });

    socket.on(SocketEvents.POSITION_UPDATE, (payload: unknown) => {
      const parsed = socketPositionSchema.safeParse(payload);
      if (!parsed.success) return;
      const { convoyId, ...position } = parsed.data;
      void updatePosition(convoyId, userIdOf(socket), position)
        .then((convoy) => io.to(convoyRoom(convoyId)).emit(SocketEvents.CONVOY_UPDATE, convoy))
        .catch(() => socket.emit('error', 'position rejected'));
    });
  });

  setIo(io);
  return io;
}
