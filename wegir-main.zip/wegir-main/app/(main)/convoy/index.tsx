import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { Button, EmptyState, Screen } from '@/components';
import { useTheme } from '@/theme';

export default function ConvoyHub() {
  const router = useRouter();
  const { spacing } = useTheme();

  return (
    <Screen title="Convoi">
      <EmptyState
        icon="convoy"
        title="Aucun convoi actif"
        description="Créez un convoi ou rejoignez celui d'un ami avec un code."
      />
      <View style={{ gap: spacing.md, marginTop: spacing.lg }}>
        <Button
          label="Créer un convoi"
          icon="plus"
          onPress={() => router.push('/(main)/convoy/create')}
        />
        <Button
          label="Rejoindre avec un code"
          icon="qr"
          variant="secondary"
          onPress={() => router.push('/(main)/convoy/join')}
        />
      </View>
    </Screen>
  );
}
