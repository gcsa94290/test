import { EmptyState, Screen } from '@/components';

export default function JoinConvoy() {
  return (
    <Screen title="Rejoindre un convoi">
      <EmptyState
        icon="qr"
        title="Rejoindre en Phase 2"
        description="Saisie du code ou scan du QR code pour entrer dans le convoi."
      />
    </Screen>
  );
}
