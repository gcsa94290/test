import { EmptyState, Screen } from '@/components';

export default function CreateConvoy() {
  return (
    <Screen title="Créer un convoi">
      <EmptyState
        icon="plus"
        title="Création de convoi en Phase 2"
        description="Nom, destination et génération du code de groupe (Firestore)."
      />
    </Screen>
  );
}
