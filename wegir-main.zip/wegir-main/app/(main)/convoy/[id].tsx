import { useLocalSearchParams } from 'expo-router';

import { EmptyState, Screen } from '@/components';

export default function ConvoyDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return (
    <Screen title="Détail convoi">
      <EmptyState
        icon="convoy"
        title={`Convoi ${id ?? ''}`}
        description="Membres, rôles, distances et itinéraire unifié arrivent en Phase 2."
      />
    </Screen>
  );
}
